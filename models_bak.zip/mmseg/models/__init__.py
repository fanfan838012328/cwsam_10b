from .builder import build_loss
from .losses import *  # noqa: F401,F403


__all__ = [
    'build_loss'
]
