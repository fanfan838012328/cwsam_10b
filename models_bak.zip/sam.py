import logging
from functools import partial
import os
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import timm
import math
from models import register
from torchvision.models import vit_b_16, vit_l_16
from .vit_modified import vit_h_14

# from transformers import ViTModel
from .mmseg.models.sam import (
    ImageEncoderViT,
    MaskDecoder,
    MaskDecoderOnlyCls,
    TwoWayTransformer,
    ImageEncoderViT_vitadp,
    ImageEncoderViT_tinyadp,
    ImageEncoderViT_vitadp_b2b,
    ImageEncoderViT_vitlora,
    ImageEncoderViT_vitlora_mix_adapter,
    ImageEncoderViT_tiny_lora_mix_adapter,
    ImageEncoderViT_vit_GAM,
    MaskDecoder_moe,
    TwoWayTransformer_moe,
    ImageEncoderViT_moe,
    ImageEncoderViT_moe_layer,
    ImageEncoderViT_soft_moe
)

logger = logging.getLogger(__name__)
from .iou_loss import IOU
from typing import Any, Optional, Tuple
from .deeplabv3plus import DeepLab
from .swin_transformerv2 import SwinTransformerV2


def onehot_to_mask(mask, palette):
    """
    Converts a mask (H, W, K) to (H, W, C)
    """
    mask = mask.permute(1, 2, 0)
    x = np.argmax(mask, axis=-1)
    colour_codes = np.array(palette)
    x = np.uint8(colour_codes[x.astype(np.uint8)])
    x = x.permute(2, 0, 1)
    return x


def init_weights(layer):
    if type(layer) == nn.Conv2d:
        nn.init.normal_(layer.weight, mean=0.0, std=0.02)
        nn.init.constant_(layer.bias, 0.0)
    elif type(layer) == nn.Linear:
        nn.init.normal_(layer.weight, mean=0.0, std=0.02)
        nn.init.constant_(layer.bias, 0.0)
    elif type(layer) == nn.BatchNorm2d:
        # print(layer)
        nn.init.normal_(layer.weight, mean=1.0, std=0.02)
        nn.init.constant_(layer.bias, 0.0)


class BBCEWithLogitLoss(nn.Module):
    '''
    Balanced BCEWithLogitLoss
    '''

    def __init__(self):
        super(BBCEWithLogitLoss, self).__init__()

    def forward(self, pred, gt):
        eps = 1e-10
        count_pos = torch.sum(gt) + eps
        count_neg = torch.sum(1.0 - gt)
        ratio = count_neg / count_pos
        w_neg = count_pos / (count_pos + count_neg)

        bce1 = nn.BCEWithLogitsLoss(pos_weight=ratio)
        loss = w_neg * bce1(pred, gt)

        return loss


def _iou_loss(pred, target):
    pred = torch.sigmoid(pred)
    inter = (pred * target).sum(dim=(2, 3))
    union = (pred + target).sum(dim=(2, 3)) - inter
    iou = 1 - (inter / union)

    return iou.mean()


class PositionEmbeddingRandom(nn.Module):
    """
    Positional encoding using random spatial frequencies.
    """

    def __init__(self, num_pos_feats: int = 64, scale: Optional[float] = None) -> None:
        super().__init__()
        if scale is None or scale <= 0.0:
            scale = 1.0
        self.register_buffer(
            "positional_encoding_gaussian_matrix",
            scale * torch.randn((2, num_pos_feats)),
        )

    def _pe_encoding(self, coords: torch.Tensor) -> torch.Tensor:
        """Positionally encode points that are normalized to [0,1]."""
        # assuming coords are in [0, 1]^2 square and have d_1 x ... x d_n x 2 shape
        coords = 2 * coords - 1
        coords = coords @ self.positional_encoding_gaussian_matrix
        coords = 2 * np.pi * coords
        # outputs d_1 x ... x d_n x C shape
        return torch.cat([torch.sin(coords), torch.cos(coords)], dim=-1)

    def forward(self, size: int) -> torch.Tensor:
        """Generate positional encoding for a grid of the specified size."""
        h, w = size, size
        device: Any = self.positional_encoding_gaussian_matrix.device
        grid = torch.ones((h, w), device=device, dtype=torch.float32)
        y_embed = grid.cumsum(dim=0) - 0.5
        x_embed = grid.cumsum(dim=1) - 0.5
        y_embed = y_embed / h
        x_embed = x_embed / w

        pe = self._pe_encoding(torch.stack([x_embed, y_embed], dim=-1))
        return pe.permute(2, 0, 1)  # C x H x W


@register('sam_bf16')
class SAM_BF16(nn.Module):
    def __init__(
        self,
        inp_size=None,
        encoder_mode=None,
        loss=None,
        num_classes=None,
        loss_weight=None,
        ignore_index=-100,
    ):
        super().__init__()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.embed_dim = encoder_mode['embed_dim']
        self.image_encoder = ImageEncoderViT_soft_moe(
            img_size=inp_size,
            patch_size=encoder_mode['patch_size'],
            in_chans=3,
            embed_dim=encoder_mode['embed_dim'],
            depth=encoder_mode['depth'],
            num_heads=encoder_mode['num_heads'],
            mlp_ratio=encoder_mode['mlp_ratio'],
            out_chans=encoder_mode['out_chans'],
            qkv_bias=encoder_mode['qkv_bias'],
            norm_layer=partial(torch.nn.LayerNorm, eps=1e-6),
            act_layer=nn.GELU,
            use_rel_pos=encoder_mode['use_rel_pos'],
            rel_pos_zero_init=True,
            window_size=encoder_mode['window_size'],
            global_attn_indexes=encoder_mode['global_attn_indexes'],
            moe_num_experts=16,
            moe_k=4,
            moe_noisy_gating=True,
            moe_start_layer_index=22
        )
        self.prompt_embed_dim = encoder_mode['prompt_embed_dim']
        self.mask_decoder = MaskDecoder_moe(
            num_multimask_outputs=3,
            transformer=TwoWayTransformer(
                depth=2,
                embedding_dim=self.prompt_embed_dim,
                mlp_dim=2048,
                num_heads=8,
            ),
            transformer_dim=self.prompt_embed_dim,
            iou_head_depth=3,
            iou_head_hidden_dim=256,
            num_classes=num_classes,
        )

        if 'evp' in encoder_mode['name']:
            for k, p in self.encoder.named_parameters():
                if (
                    "prompt" not in k
                    and "mask_decoder" not in k
                    and "prompt_encoder" not in k
                ):
                    p.requires_grad = False

        self.loss_mode = loss
        self.ignore_index = ignore_index

        if self.loss_mode == 'bce':
            self.criterionBCE = torch.nn.BCEWithLogitsLoss(reduction='none')

        elif self.loss_mode == 'bbce':
            self.criterionBCE = BBCEWithLogitLoss(reduction='none')

        elif self.loss_mode == 'iou':
            # self.criterionBCE = torch.nn.BCEWithLogitsLoss()
            # pos_weight = torch.tensor([1.5, 1, 0.5, 1.9, 0.1], dtype=torch.float)
            if loss_weight is not None:
                pos_weight = torch.tensor(loss_weight, dtype=torch.float)
                self.criterionBCE = torch.nn.CrossEntropyLoss(
                    pos_weight, ignore_index=self.ignore_index
                )
            else:
                self.criterionBCE = torch.nn.CrossEntropyLoss(
                    ignore_index=self.ignore_index
                )

            self.criterionIOU = IOU()

        # elif self.loss_mode == 'iou_ce':
        #     self.criterionBCE =  torch.nn.CrossEntropyLoss()
        #     self.criterionIOU = IOU()

        self.pe_layer = PositionEmbeddingRandom(encoder_mode['prompt_embed_dim'] // 2)
        self.inp_size = inp_size
        self.image_embedding_size = inp_size // encoder_mode['patch_size']
        self.no_mask_embed = nn.Embedding(1, encoder_mode['prompt_embed_dim'])

    def set_input(self, input, gt_mask):
        self.input = input.to(self.device)
        self.gt_mask = gt_mask.to(self.device)

    def get_dense_pe(self) -> torch.Tensor:
        """
        Returns the positional encoding used to encode point prompts,
        applied to a dense set of points the shape of the image encoding.

        Returns:
          torch.Tensor: Positional encoding with shape
            1x(embed_dim)x(embedding_h)x(embedding_w)
        """
        return self.pe_layer(self.image_embedding_size).unsqueeze(0)

    def forward(self):
        # bs = 1
        bs = self.input.shape[0]

        # Embed prompts
        sparse_embeddings = torch.empty(
            (bs, 0, self.prompt_embed_dim), device=self.input.device
        )
        dense_embeddings = self.no_mask_embed.weight.reshape(1, -1, 1, 1).expand(
            bs, -1, self.image_embedding_size, self.image_embedding_size
        )

        self.features = self.image_encoder(self.input)

        # Predict masks
        low_res_masks, iou_predictions = self.mask_decoder(
            image_embeddings=self.features,
            image_pe=self.get_dense_pe(),
            sparse_prompt_embeddings=sparse_embeddings,
            dense_prompt_embeddings=dense_embeddings,
            multimask_output=False,
        )

        # Upscale the masks to the original image resolution
        masks = self.postprocess_masks(low_res_masks, self.inp_size, self.inp_size)
        self.pred_mask = masks

    def infer(self, input):
        bs = 1

        # Embed prompts
        sparse_embeddings = torch.empty(
            (bs, 0, self.prompt_embed_dim), device=input.device
        )
        dense_embeddings = self.no_mask_embed.weight.reshape(1, -1, 1, 1).expand(
            bs, -1, self.image_embedding_size, self.image_embedding_size
        )

        self.features = self.image_encoder(input)  # 第一个val 第二张图推理循环 显存+5G

        # Predict masks
        low_res_masks, iou_predictions = self.mask_decoder(
            image_embeddings=self.features,
            image_pe=self.get_dense_pe(),
            sparse_prompt_embeddings=sparse_embeddings,
            dense_prompt_embeddings=dense_embeddings,
            multimask_output=False,
        )

        # Upscale the masks to the original image resolution
        masks = self.postprocess_masks(low_res_masks, self.inp_size, self.inp_size)
        # masks_rgb= onehot_to_mask(masks)
        return masks

    def postprocess_masks(
        self,
        masks: torch.Tensor,
        input_size: Tuple[int, ...],
        original_size: Tuple[int, ...],
    ) -> torch.Tensor:
        """
        Remove padding and upscale masks to the original image size.

        Arguments:
          masks (torch.Tensor): Batched masks from the mask_decoder,
            in BxCxHxW format.
          input_size (tuple(int, int)): The size of the image input to the
            model, in (H, W) format. Used to remove padding.
          original_size (tuple(int, int)): The original size of the image
            before resizing for input to the model, in (H, W) format.

        Returns:
          (torch.Tensor): Batched masks in BxCxHxW format, where (H, W)
            is given by original_size.
        """
        # masks = masks[0]
        masks = masks.squeeze(dim=1)
        masks = F.interpolate(
            masks,
            (self.image_encoder.img_size, self.image_encoder.img_size),
            mode="bilinear",
            align_corners=False,
        )
        masks = masks[..., :input_size, :input_size]
        masks = F.interpolate(
            masks, original_size, mode="bilinear", align_corners=False
        )
        return masks

    def get_ignore_mask_loss(self, loss, ignore_index: list = None):
        """Create a mask to ignore certain pixels in the ground truth."""
        # 创建一个掩码
        mask = torch.ones_like(loss, device=loss.device)

        # 对于每个要屏蔽的类别，将掩码设置为0
        for index in ignore_index:
            mask[torch.argmax(self.gt_mask, dim=1) == index] = 0

        # 应用掩码到损失上
        loss = loss * mask
        return loss.sum() / torch.ones_like(loss, device=loss.device).sum()
    def get_current_loss(self):
        """
        Calculates and returns the current loss based on self.pred_mask and self.gt_mask.
        This method should be called after self.set_input() and self.forward().
        """
        if not hasattr(self, 'pred_mask') or self.pred_mask is None:
            raise RuntimeError(
                "pred_mask is not set. Call forward() to compute predictions first."
            )
        if not hasattr(self, 'gt_mask') or self.gt_mask is None:
            raise RuntimeError(
                "gt_mask is not set. Call set_input() to provide ground truth first."
            )

        # 损失计算逻辑 (与 backward_G 中的损失计算部分类似)
        # 注意：这里的 self.gt_mask 应该是 one-hot 编码的 (B, NumClasses, H, W)
        # self.criterionBCE 通常是 CrossEntropyLoss，它期望的目标是 (B, H, W) 的类别索引
        target_for_loss = torch.argmax(self.gt_mask, dim=1) # 将 one-hot gt 转换为类别索引

        loss = self.criterionBCE(self.pred_mask, target_for_loss)

        # 如果您计划使用 IoU 损失或其他损失，也在这里添加
        # 例如，如果 self.loss_mode == 'iou' 并且 self.criterionIOU 定义了:
        # if hasattr(self, 'criterionIOU') and self.loss_mode == 'iou':
        #     iou_loss_value = self.criterionIOU(torch.sigmoid(self.pred_mask), self.gt_mask.float()) # 假设 IOU 需要 sigmoid 和 float target
        #     loss += iou_loss_value # 或者根据您的损失组合方式

        self.loss_G = loss # 可选：仍然将计算出的损失存储在 self.loss_G 中，以防模型其他部分需要
        return loss
    def backward_G(self):
        """Calculate GAN and L1 loss for the generator"""
        # 这个方法现在可以只负责计算损失并存储，或者如果 optimize_parameters 仍被其他地方使用，
        # 它可以依赖 get_current_loss() 然后执行 backward。
        # 为了与 train.py 的 AMP 逻辑解耦，建议不在这个方法中直接调用 self.loss_G.backward()
        # 如果 optimize_parameters 是主要的训练方式，则它应该调用 get_current_loss 并进行 backward。

        # 当前的 backward_G 实现:
        # loss = self.criterionBCE(
        #     self.pred_mask, torch.argmax(self.gt_mask, dim=1, keepdim=True).squeeze(1)
        # )
        # self.loss_G = loss
        # # if self.loss_mode == 'iou':
        # # self.loss_G += _iou_loss(self.pred_mask, self.gt_mask)
        # self.loss_G.backward() # <--- 对于外部 AMP 控制，这一行应该被移除或移到 optimize_parameters

        # 建议修改 backward_G (如果 optimize_parameters 仍被使用):
        if not hasattr(self, 'optimizer'): # 确保优化器已设置
             raise RuntimeError("Optimizer not set for SAM model.")
        
        current_loss = self.get_current_loss() # 获取损失
        # self.loss_G 已经在 get_current_loss 中被赋值

        # 如果此方法仍然负责反向传播 (例如被 optimize_parameters 调用)
        current_loss.backward()

    def optimize_parameters(self):
        # 此方法现在应该按以下顺序执行：
        self.forward()                   # 1. 计算预测
        self.optimizer.zero_grad()       # 2. 梯度清零
        self.backward_G()                # 3. 计算损失并执行反向传播 (backward_G 内部处理)
        self.optimizer.step()            # 4. 更新权重


    def set_requires_grad(self, nets, requires_grad=False):
        """Set requies_grad=Fasle for all the networks to avoid unnecessary computations
        Parameters:
            nets (network list)   -- a list of networks
            requires_grad (bool)  -- whether the networks require gradients or not
        """
        if not isinstance(nets, list):
            nets = [nets]
        for net in nets:
            if net is not None:
                for param in net.parameters():
                    param.requires_grad = requires_grad
@register('sam')
class SAM(nn.Module):
    def __init__(
        self,
        inp_size=None,
        encoder_mode=None,
        loss=None,
        num_classes=None,
        loss_weight=None,
        ignore_index=-100,
    ):
        super().__init__()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.embed_dim = encoder_mode['embed_dim']
        self.image_encoder = ImageEncoderViT(
            img_size=inp_size,
            patch_size=encoder_mode['patch_size'],
            in_chans=3,
            embed_dim=encoder_mode['embed_dim'],
            depth=encoder_mode['depth'],
            num_heads=encoder_mode['num_heads'],
            mlp_ratio=encoder_mode['mlp_ratio'],
            out_chans=encoder_mode['out_chans'],
            qkv_bias=encoder_mode['qkv_bias'],
            norm_layer=partial(torch.nn.LayerNorm, eps=1e-6),
            act_layer=nn.GELU,
            use_rel_pos=encoder_mode['use_rel_pos'],
            rel_pos_zero_init=True,
            window_size=encoder_mode['window_size'],
            global_attn_indexes=encoder_mode['global_attn_indexes'],
        )
        self.prompt_embed_dim = encoder_mode['prompt_embed_dim']
        self.mask_decoder = MaskDecoder(
            num_multimask_outputs=3,
            transformer=TwoWayTransformer(
                depth=2,
                embedding_dim=self.prompt_embed_dim,
                mlp_dim=2048,
                num_heads=8,
            ),
            transformer_dim=self.prompt_embed_dim,
            iou_head_depth=3,
            iou_head_hidden_dim=256,
            num_classes=num_classes,
        )

        if 'evp' in encoder_mode['name']:
            for k, p in self.encoder.named_parameters():
                if (
                    "prompt" not in k
                    and "mask_decoder" not in k
                    and "prompt_encoder" not in k
                ):
                    p.requires_grad = False

        self.loss_mode = loss
        self.ignore_index = ignore_index

        if self.loss_mode == 'bce':
            self.criterionBCE = torch.nn.BCEWithLogitsLoss(reduction='none')

        elif self.loss_mode == 'bbce':
            self.criterionBCE = BBCEWithLogitLoss(reduction='none')

        elif self.loss_mode == 'iou':
            # self.criterionBCE = torch.nn.BCEWithLogitsLoss()
            # pos_weight = torch.tensor([1.5, 1, 0.5, 1.9, 0.1], dtype=torch.float)
            if loss_weight is not None:
                pos_weight = torch.tensor(loss_weight, dtype=torch.float)
                self.criterionBCE = torch.nn.CrossEntropyLoss(
                    pos_weight, ignore_index=self.ignore_index
                )
            else:
                self.criterionBCE = torch.nn.CrossEntropyLoss(
                    ignore_index=self.ignore_index
                )

            self.criterionIOU = IOU()

        # elif self.loss_mode == 'iou_ce':
        #     self.criterionBCE =  torch.nn.CrossEntropyLoss()
        #     self.criterionIOU = IOU()

        self.pe_layer = PositionEmbeddingRandom(encoder_mode['prompt_embed_dim'] // 2)
        self.inp_size = inp_size
        self.image_embedding_size = inp_size // encoder_mode['patch_size']
        self.no_mask_embed = nn.Embedding(1, encoder_mode['prompt_embed_dim'])

    def set_input(self, input, gt_mask):
        self.input = input.to(self.device)
        self.gt_mask = gt_mask.to(self.device)

    def get_dense_pe(self) -> torch.Tensor:
        """
        Returns the positional encoding used to encode point prompts,
        applied to a dense set of points the shape of the image encoding.

        Returns:
          torch.Tensor: Positional encoding with shape
            1x(embed_dim)x(embedding_h)x(embedding_w)
        """
        return self.pe_layer(self.image_embedding_size).unsqueeze(0)

    def forward(self):
        # bs = 1
        bs = self.input.shape[0]

        # Embed prompts
        sparse_embeddings = torch.empty(
            (bs, 0, self.prompt_embed_dim), device=self.input.device
        )
        dense_embeddings = self.no_mask_embed.weight.reshape(1, -1, 1, 1).expand(
            bs, -1, self.image_embedding_size, self.image_embedding_size
        )

        self.features = self.image_encoder(self.input)

        # Predict masks
        low_res_masks, iou_predictions = self.mask_decoder(
            image_embeddings=self.features,
            image_pe=self.get_dense_pe(),
            sparse_prompt_embeddings=sparse_embeddings,
            dense_prompt_embeddings=dense_embeddings,
            multimask_output=False,
        )

        # Upscale the masks to the original image resolution
        masks = self.postprocess_masks(low_res_masks, self.inp_size, self.inp_size)
        self.pred_mask = masks

    def infer(self, input):
        bs = 1

        # Embed prompts
        sparse_embeddings = torch.empty(
            (bs, 0, self.prompt_embed_dim), device=input.device
        )
        dense_embeddings = self.no_mask_embed.weight.reshape(1, -1, 1, 1).expand(
            bs, -1, self.image_embedding_size, self.image_embedding_size
        )

        self.features = self.image_encoder(input)  # 第一个val 第二张图推理循环 显存+5G

        # Predict masks
        low_res_masks, iou_predictions = self.mask_decoder(
            image_embeddings=self.features,
            image_pe=self.get_dense_pe(),
            sparse_prompt_embeddings=sparse_embeddings,
            dense_prompt_embeddings=dense_embeddings,
            multimask_output=False,
        )

        # Upscale the masks to the original image resolution
        masks = self.postprocess_masks(low_res_masks, self.inp_size, self.inp_size)
        # masks_rgb= onehot_to_mask(masks)
        return masks

    def postprocess_masks(
        self,
        masks: torch.Tensor,
        input_size: Tuple[int, ...],
        original_size: Tuple[int, ...],
    ) -> torch.Tensor:
        """
        Remove padding and upscale masks to the original image size.

        Arguments:
          masks (torch.Tensor): Batched masks from the mask_decoder,
            in BxCxHxW format.
          input_size (tuple(int, int)): The size of the image input to the
            model, in (H, W) format. Used to remove padding.
          original_size (tuple(int, int)): The original size of the image
            before resizing for input to the model, in (H, W) format.

        Returns:
          (torch.Tensor): Batched masks in BxCxHxW format, where (H, W)
            is given by original_size.
        """
        # masks = masks[0]
        masks = masks.squeeze(dim=1)
        masks = F.interpolate(
            masks,
            (self.image_encoder.img_size, self.image_encoder.img_size),
            mode="bilinear",
            align_corners=False,
        )
        masks = masks[..., :input_size, :input_size]
        masks = F.interpolate(
            masks, original_size, mode="bilinear", align_corners=False
        )
        return masks

    def get_ignore_mask_loss(self, loss, ignore_index: list = None):
        """Create a mask to ignore certain pixels in the ground truth."""
        # 创建一个掩码
        mask = torch.ones_like(loss, device=loss.device)

        # 对于每个要屏蔽的类别，将掩码设置为0
        for index in ignore_index:
            mask[torch.argmax(self.gt_mask, dim=1) == index] = 0

        # 应用掩码到损失上
        loss = loss * mask
        return loss.sum() / torch.ones_like(loss, device=loss.device).sum()

    def backward_G(self):
        """Calculate GAN and L1 loss for the generator"""
        # mask = self.create_ignore_mask(self.gt_mask, ignore_index=self.ignore_index)

        loss = self.criterionBCE(
            self.pred_mask, torch.argmax(self.gt_mask, dim=1, keepdim=True).squeeze(1)
        )  # (1,4,1024,1024)
        # print(
        #     f'未忽略类别loss:{self.criterionBCE(self.pred_mask, self.gt_mask).mean()}'
        # )
        # guanfang_crt = torch.nn.CrossEntropyLoss(ignore_index=0)
        # guanfang_loss = guanfang_crt(
        #     self.pred_mask, torch.argmax(self.gt_mask, dim=1, keepdim=True).squeeze(1)
        # )
        # print(f'guanfang忽略类别loss:{guanfang_loss}')
        # loss = self.get_ignore_mask_loss(loss, ignore_index=self.ignore_index)
        # print(f'忽略类别loss:{loss}')

        # loss = loss * mask  # 应用掩码
        # loss = loss.sum() / mask.sum()  # 仅计算非忽略像素的损失
        self.loss_G = loss
        # if self.loss_mode == 'iou':
        # self.loss_G += _iou_loss(self.pred_mask, self.gt_mask)

        self.loss_G.backward()

    def optimize_parameters(self):
        self.forward()
        self.optimizer.zero_grad()  # set G's gradients to zero
        self.backward_G()  # calculate graidents for G
        self.optimizer.step()  # udpate G's weights

    def set_requires_grad(self, nets, requires_grad=False):
        """Set requies_grad=Fasle for all the networks to avoid unnecessary computations
        Parameters:
            nets (network list)   -- a list of networks
            requires_grad (bool)  -- whether the networks require gradients or not
        """
        if not isinstance(nets, list):
            nets = [nets]
        for net in nets:
            if net is not None:
                for param in net.parameters():
                    param.requires_grad = requires_grad
@register('sam_moe_3b')
class SAM_MOE_3B(nn.Module):
    def __init__(
        self,
        inp_size=None,
        encoder_mode=None,
        loss=None,
        num_classes=None,
        loss_weight=None,
        ignore_index=-100,
    ):
        super().__init__()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.embed_dim = encoder_mode['embed_dim']
        self.image_encoder = ImageEncoderViT_moe_layer(
            img_size=inp_size,
            patch_size=encoder_mode['patch_size'],
            in_chans=3,
            embed_dim=encoder_mode['embed_dim'],
            depth=encoder_mode['depth'],
            num_heads=encoder_mode['num_heads'],
            mlp_ratio=encoder_mode['mlp_ratio'],
            out_chans=encoder_mode['out_chans'],
            qkv_bias=encoder_mode['qkv_bias'],
            norm_layer=partial(torch.nn.LayerNorm, eps=1e-6),
            act_layer=nn.GELU,
            use_rel_pos=encoder_mode['use_rel_pos'],
            rel_pos_zero_init=True,
            window_size=encoder_mode['window_size'],
            global_attn_indexes=encoder_mode['global_attn_indexes'],
            moe_num_experts=16,
            moe_k=4,
            moe_noisy_gating=True,
            moe_start_layer_index=28
        )
        self.prompt_embed_dim = encoder_mode['prompt_embed_dim']
        self.mask_decoder = MaskDecoder(
            num_multimask_outputs=3,
            transformer=TwoWayTransformer_moe(
                depth=2,
                embedding_dim=self.prompt_embed_dim,
                mlp_dim=2048,
                num_heads=8,
            ),
            transformer_dim=self.prompt_embed_dim,
            iou_head_depth=3,
            iou_head_hidden_dim=256,
            num_classes=num_classes,
        )

        if 'evp' in encoder_mode['name']:
            for k, p in self.encoder.named_parameters():
                if (
                    "prompt" not in k
                    and "mask_decoder" not in k
                    and "prompt_encoder" not in k
                ):
                    p.requires_grad = False

        self.loss_mode = loss
        self.ignore_index = ignore_index

        if self.loss_mode == 'bce':
            self.criterionBCE = torch.nn.BCEWithLogitsLoss(reduction='none')

        elif self.loss_mode == 'bbce':
            self.criterionBCE = BBCEWithLogitLoss(reduction='none')

        elif self.loss_mode == 'iou':
            # self.criterionBCE = torch.nn.BCEWithLogitsLoss()
            # pos_weight = torch.tensor([1.5, 1, 0.5, 1.9, 0.1], dtype=torch.float)
            if loss_weight is not None:
                pos_weight = torch.tensor(loss_weight, dtype=torch.float)
                self.criterionBCE = torch.nn.CrossEntropyLoss(
                    pos_weight, ignore_index=self.ignore_index
                )
            else:
                self.criterionBCE = torch.nn.CrossEntropyLoss(
                    ignore_index=self.ignore_index
                )

            self.criterionIOU = IOU()

        # elif self.loss_mode == 'iou_ce':
        #     self.criterionBCE =  torch.nn.CrossEntropyLoss()
        #     self.criterionIOU = IOU()

        self.pe_layer = PositionEmbeddingRandom(encoder_mode['prompt_embed_dim'] // 2)
        self.inp_size = inp_size
        self.image_embedding_size = inp_size // encoder_mode['patch_size']
        self.no_mask_embed = nn.Embedding(1, encoder_mode['prompt_embed_dim'])

    def set_input(self, input, gt_mask):
        self.input = input.to(self.device)
        self.gt_mask = gt_mask.to(self.device)

    def get_dense_pe(self) -> torch.Tensor:
        """
        Returns the positional encoding used to encode point prompts,
        applied to a dense set of points the shape of the image encoding.

        Returns:
          torch.Tensor: Positional encoding with shape
            1x(embed_dim)x(embedding_h)x(embedding_w)
        """
        return self.pe_layer(self.image_embedding_size).unsqueeze(0)

    def forward(self):
        # bs = 1
        bs = self.input.shape[0]

        # Embed prompts
        sparse_embeddings = torch.empty(
            (bs, 0, self.prompt_embed_dim), device=self.input.device
        )
        dense_embeddings = self.no_mask_embed.weight.reshape(1, -1, 1, 1).expand(
            bs, -1, self.image_embedding_size, self.image_embedding_size
        )

        self.features = self.image_encoder(self.input)

        # Predict masks
        low_res_masks, iou_predictions = self.mask_decoder(
            image_embeddings=self.features,
            image_pe=self.get_dense_pe(),
            sparse_prompt_embeddings=sparse_embeddings,
            dense_prompt_embeddings=dense_embeddings,
            multimask_output=False,
        )

        # Upscale the masks to the original image resolution
        masks = self.postprocess_masks(low_res_masks, self.inp_size, self.inp_size)
        self.pred_mask = masks

    def infer(self, input):
        bs = 1

        # Embed prompts
        sparse_embeddings = torch.empty(
            (bs, 0, self.prompt_embed_dim), device=input.device
        )
        dense_embeddings = self.no_mask_embed.weight.reshape(1, -1, 1, 1).expand(
            bs, -1, self.image_embedding_size, self.image_embedding_size
        )

        self.features = self.image_encoder(input)  # 第一个val 第二张图推理循环 显存+5G

        # Predict masks
        low_res_masks, iou_predictions = self.mask_decoder(
            image_embeddings=self.features,
            image_pe=self.get_dense_pe(),
            sparse_prompt_embeddings=sparse_embeddings,
            dense_prompt_embeddings=dense_embeddings,
            multimask_output=False,
        )

        # Upscale the masks to the original image resolution
        masks = self.postprocess_masks(low_res_masks, self.inp_size, self.inp_size)
        # masks_rgb= onehot_to_mask(masks)
        return masks

    def postprocess_masks(
        self,
        masks: torch.Tensor,
        input_size: Tuple[int, ...],
        original_size: Tuple[int, ...],
    ) -> torch.Tensor:
        """
        Remove padding and upscale masks to the original image size.

        Arguments:
          masks (torch.Tensor): Batched masks from the mask_decoder,
            in BxCxHxW format.
          input_size (tuple(int, int)): The size of the image input to the
            model, in (H, W) format. Used to remove padding.
          original_size (tuple(int, int)): The original size of the image
            before resizing for input to the model, in (H, W) format.

        Returns:
          (torch.Tensor): Batched masks in BxCxHxW format, where (H, W)
            is given by original_size.
        """
        # masks = masks[0]
        masks = masks.squeeze(dim=1)
        masks = F.interpolate(
            masks,
            (self.image_encoder.img_size, self.image_encoder.img_size),
            mode="bilinear",
            align_corners=False,
        )
        masks = masks[..., :input_size, :input_size]
        masks = F.interpolate(
            masks, original_size, mode="bilinear", align_corners=False
        )
        return masks

    def get_ignore_mask_loss(self, loss, ignore_index: list = None):
        """Create a mask to ignore certain pixels in the ground truth."""
        # 创建一个掩码
        mask = torch.ones_like(loss, device=loss.device)

        # 对于每个要屏蔽的类别，将掩码设置为0
        for index in ignore_index:
            mask[torch.argmax(self.gt_mask, dim=1) == index] = 0

        # 应用掩码到损失上
        loss = loss * mask
        return loss.sum() / torch.ones_like(loss, device=loss.device).sum()

    def backward_G(self):
        """Calculate GAN and L1 loss for the generator"""
        # mask = self.create_ignore_mask(self.gt_mask, ignore_index=self.ignore_index)

        loss = self.criterionBCE(
            self.pred_mask, torch.argmax(self.gt_mask, dim=1, keepdim=True).squeeze(1)
        )  # (1,4,1024,1024)
        # print(
        #     f'未忽略类别loss:{self.criterionBCE(self.pred_mask, self.gt_mask).mean()}'
        # )
        # guanfang_crt = torch.nn.CrossEntropyLoss(ignore_index=0)
        # guanfang_loss = guanfang_crt(
        #     self.pred_mask, torch.argmax(self.gt_mask, dim=1, keepdim=True).squeeze(1)
        # )
        # print(f'guanfang忽略类别loss:{guanfang_loss}')
        # loss = self.get_ignore_mask_loss(loss, ignore_index=self.ignore_index)
        # print(f'忽略类别loss:{loss}')

        # loss = loss * mask  # 应用掩码
        # loss = loss.sum() / mask.sum()  # 仅计算非忽略像素的损失
        self.loss_G = loss
        # if self.loss_mode == 'iou':
        # self.loss_G += _iou_loss(self.pred_mask, self.gt_mask)

        self.loss_G.backward()

    def optimize_parameters(self):
        self.forward()
        self.optimizer.zero_grad()  # set G's gradients to zero
        self.backward_G()  # calculate graidents for G
        self.optimizer.step()  # udpate G's weights

    def set_requires_grad(self, nets, requires_grad=False):
        """Set requies_grad=Fasle for all the networks to avoid unnecessary computations
        Parameters:
            nets (network list)   -- a list of networks
            requires_grad (bool)  -- whether the networks require gradients or not
        """
        if not isinstance(nets, list):
            nets = [nets]
        for net in nets:
            if net is not None:
                for param in net.parameters():
                    param.requires_grad = requires_grad



@register('sam_moe_3b_amp')
class SAM_MOE_3b_amp(nn.Module):
    def __init__(
        self,
        inp_size=None,
        encoder_mode=None,
        loss=None,
        num_classes=None,
        loss_weight=None,
        ignore_index=-100,
    ):
        super().__init__()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.embed_dim = encoder_mode['embed_dim']
        
        # 添加混合精度训练的标志，默认启用
        self.use_amp = True
        
        self.image_encoder = ImageEncoderViT_moe_layer(
            img_size=inp_size,
            patch_size=encoder_mode['patch_size'],
            in_chans=3,
            embed_dim=encoder_mode['embed_dim'],
            depth=encoder_mode['depth'],
            num_heads=encoder_mode['num_heads'],
            mlp_ratio=encoder_mode['mlp_ratio'],
            out_chans=encoder_mode['out_chans'],
            qkv_bias=encoder_mode['qkv_bias'],
            norm_layer=partial(torch.nn.LayerNorm, eps=1e-6),
            act_layer=nn.GELU,
            use_rel_pos=encoder_mode['use_rel_pos'],
            rel_pos_zero_init=True,
            window_size=encoder_mode['window_size'],
            global_attn_indexes=encoder_mode['global_attn_indexes'],
            moe_num_experts=16,
            moe_k=4,
            moe_noisy_gating=True,
            moe_start_layer_index=24
        )
        self.prompt_embed_dim = encoder_mode['prompt_embed_dim']
        self.mask_decoder = MaskDecoder_moe(
            num_multimask_outputs=3,
            transformer=TwoWayTransformer_moe(
                depth=2,
                embedding_dim=self.prompt_embed_dim,
                mlp_dim=2048,
                num_heads=8,
            ),
            transformer_dim=self.prompt_embed_dim,
            iou_head_depth=3,
            iou_head_hidden_dim=256,
            num_classes=num_classes,
        )

        if 'evp' in encoder_mode['name']:
            for k, p in self.encoder.named_parameters():
                if (
                    "prompt" not in k
                    and "mask_decoder" not in k
                    and "prompt_encoder" not in k
                ):
                    p.requires_grad = False

        self.loss_mode = loss
        self.ignore_index = ignore_index

        if self.loss_mode == 'bce':
            self.criterionBCE = torch.nn.BCEWithLogitsLoss(reduction='none')

        elif self.loss_mode == 'bbce':
            self.criterionBCE = BBCEWithLogitLoss(reduction='none')

        elif self.loss_mode == 'iou':
            # self.criterionBCE = torch.nn.BCEWithLogitsLoss()
            # pos_weight = torch.tensor([1.5, 1, 0.5, 1.9, 0.1], dtype=torch.float)
            if loss_weight is not None:
                pos_weight = torch.tensor(loss_weight, dtype=torch.float)
                self.criterionBCE = torch.nn.CrossEntropyLoss(
                    pos_weight, ignore_index=self.ignore_index
                )
            else:
                self.criterionBCE = torch.nn.CrossEntropyLoss(
                    ignore_index=self.ignore_index
                )

            self.criterionIOU = IOU()

        # elif self.loss_mode == 'iou_ce':
        #     self.criterionBCE =  torch.nn.CrossEntropyLoss()
        #     self.criterionIOU = IOU()

        self.pe_layer = PositionEmbeddingRandom(encoder_mode['prompt_embed_dim'] // 2)
        self.inp_size = inp_size
        self.image_embedding_size = inp_size // encoder_mode['patch_size']
        self.no_mask_embed = nn.Embedding(1, encoder_mode['prompt_embed_dim'])

    def set_input(self, input, gt_mask):
        self.input = input.to(self.device)
        self.gt_mask = gt_mask.to(self.device)

    def get_dense_pe(self) -> torch.Tensor:
        """
        Returns the positional encoding used to encode point prompts,
        applied to a dense set of points the shape of the image encoding.

        Returns:
          torch.Tensor: Positional encoding with shape
            1x(embed_dim)x(embedding_h)x(embedding_w)
        """
        return self.pe_layer(self.image_embedding_size).unsqueeze(0)

    def forward(self):
        """前向传播，计算预测结果但不计算损失"""
        # 首先检查输入数据是否包含NaN或无穷大值
        if torch.isnan(self.input).any() or torch.isinf(self.input).any():
            print("输入图像包含NaN或Inf值！尝试修复...")
            self.input = torch.nan_to_num(self.input, nan=0.0, posinf=1.0, neginf=0.0)
        
        try:
            # 使用双精度进行特征提取
            with torch.cuda.amp.autocast(enabled=self.use_amp):
                features = self.image_encoder(self.input)
                
                # 检查特征中的NaN
                if torch.isnan(features).any() or torch.isinf(features).any():
                    print(f"警告：图像编码器输出包含NaN/Inf！进行修正")
                    # 替换特征中的NaN值为0
                    features = torch.nan_to_num(features, nan=0.0, posinf=0.0, neginf=0.0)
                    print(f"修正后特征统计：min={features.min().item()}, max={features.max().item()}, mean={features.mean().item()}")
        except Exception as e:
            print(f"图像编码器前向传播错误: {e}")
            # 创建一个零特征张量
            features = torch.zeros(
                (self.input.shape[0], self.embed_dim, 
                 self.input.shape[2]//16, self.input.shape[3]//16), 
                device=self.input.device
            )

        # bs = 1
        bs = self.input.shape[0]

        # Embed prompts
        sparse_embeddings = torch.empty(
            (bs, 0, self.prompt_embed_dim), device=self.input.device
        )
        dense_embeddings = self.no_mask_embed.weight.reshape(1, -1, 1, 1).expand(
            bs, -1, self.image_embedding_size, self.image_embedding_size
        )

        # Process each item in the batch individually (as in original code)
        all_low_res_masks = []
        for i in range(bs):
            try:
                this_features = features[i].unsqueeze(0) # Get features for this item
                this_dense_embeddings = dense_embeddings[i].unsqueeze(0)
                this_sparse_embeddings = sparse_embeddings[i].unsqueeze(0) if sparse_embeddings.shape[1] > 0 else sparse_embeddings.new_empty(1, 0, self.prompt_embed_dim)

                # 进行掩码解码
                with torch.cuda.amp.autocast(enabled=self.use_amp):
                    low_res_masks, iou_predictions = self.mask_decoder(
                        image_embeddings=this_features,
                        image_pe=self.get_dense_pe(),
                        sparse_prompt_embeddings=this_sparse_embeddings,
                        dense_prompt_embeddings=this_dense_embeddings,
                        multimask_output=False,
                    )
                
                # 检查掩码解码器输出
                if torch.isnan(low_res_masks).any() or torch.isinf(low_res_masks).any():
                    print(f"警告: 批次项 {i} 的掩码解码器输出包含NaN/Inf")
                    # 创建零掩码
                    low_res_masks = torch.zeros_like(low_res_masks)
                
                all_low_res_masks.append(low_res_masks)
            except Exception as e:
                print(f"处理批次项 {i} 时出错: {e}")
                # 创建零掩码作为后备
                # 推断形状
                h, w = self.image_embedding_size, self.image_embedding_size
                num_classes = self.mask_decoder.num_mask_tokens  # 通常是类别数
                zero_mask = torch.zeros((1, num_classes, h, w), device=self.input.device)
                all_low_res_masks.append(zero_mask)

        # 合并批次结果
        try:
            # 假设mask_decoder为每个项输出[1, num_classes, H, W]
            combined_low_res_masks = torch.cat(all_low_res_masks, dim=0)
            
            # 上采样掩码到原始图像分辨率
            masks = self.postprocess_masks(combined_low_res_masks, self.inp_size, self.inp_size)
            
            # 最终检查
            if torch.isnan(masks).any() or torch.isinf(masks).any():
                print("后处理后的掩码包含NaN/Inf，进行修正")
                masks = torch.nan_to_num(masks, nan=0.0, posinf=0.0, neginf=0.0)
        except Exception as e:
            print(f"掩码后处理错误: {e}")
            # 创建零掩码作为后备
            masks = torch.zeros(
                (bs, self.mask_decoder.num_mask_tokens, self.inp_size, self.inp_size), 
                device=self.input.device
            )

        self.pred_mask = masks

    def compute_loss(self):
        """计算损失但不执行优化步骤"""
        # 首先检查pred_mask是否包含NaN
        if torch.isnan(self.pred_mask).any() or torch.isinf(self.pred_mask).any():
            print("警告：pred_mask包含NaN或Inf值，进行修正")
            self.pred_mask = torch.nan_to_num(self.pred_mask, nan=0.0, posinf=0.0, neginf=0.0)
            
        # 检查gt_mask
        if torch.isnan(self.gt_mask).any() or torch.isinf(self.gt_mask).any():
            print("警告：gt_mask包含NaN或Inf值，进行修正")
            self.gt_mask = torch.nan_to_num(self.gt_mask, nan=0.0, posinf=0.0, neginf=0.0)
        
        try:
            # 使用混合精度计算损失
            with torch.cuda.amp.autocast(enabled=self.use_amp):
                if self.loss_mode == 'iou':
                    # 检查pred_mask的实际维度
                    pred_shape = self.pred_mask.shape
                    
                    # 根据pred_mask的实际维度进行处理
                    if len(pred_shape) == 5:  # 如果是[b,n,c,h,w]格式
                        b, n, c, h, w = pred_shape
                        # 重新整形为4D张量以便于处理
                        self.pred_mask = self.pred_mask.view(b*n, c, h, w)
                    elif len(pred_shape) != 4:
                        # 处理异常情况
                        print(f"警告：pred_mask形状异常: {pred_shape}")
                        # 尝试适应不同的形状
                        if len(pred_shape) > 4:
                            # 从右侧取最后4个维度
                            self.pred_mask = self.pred_mask.reshape(-1, *pred_shape[-3:])
                            
                    # 获取调整后的形状
                    b, c, h, w = self.pred_mask.shape
                    
                    # 将目标下采样到预测的分辨率
                    gt_mask_downsampled = F.interpolate(
                        self.gt_mask, 
                        size=(h, w),
                        mode="nearest"
                    )
                    
                    # 获取类别索引，而不是one-hot编码
                    gt_indices = torch.argmax(gt_mask_downsampled, dim=1, keepdim=False)
                    
                    # 应用数值裁剪确保预测值在合理范围内
                    self.pred_mask = torch.clamp(self.pred_mask, min=-100.0, max=100.0)
                    
                    # 应用交叉熵损失
                    print(f"pred_mask稳定性检查 - min: {self.pred_mask.min().item()}, max: {self.pred_mask.max().item()}, mean: {self.pred_mask.mean().item()}")
                    
                    # 保证输入CrossEntropyLoss的输入没有NaN/Inf
                    if torch.isnan(self.pred_mask).any() or torch.isinf(self.pred_mask).any():
                        print("进一步修正pred_mask中的NaN/Inf")
                        self.pred_mask = torch.nan_to_num(self.pred_mask, nan=0.0, posinf=0.0, neginf=0.0)
                    
                    try:
                        loss = self.criterionBCE(self.pred_mask, gt_indices)
                        
                        # 检查损失值
                        if torch.isnan(loss).any() or torch.isinf(loss).any():
                            print("警告：损失计算结果为NaN或Inf，使用零损失替代")
                            loss = torch.tensor(0.0, device=self.pred_mask.device, requires_grad=True)
                    except Exception as e:
                        print(f"损失计算出错: {e}")
                        # 创建零损失作为后备
                        loss = torch.tensor(0.0, device=self.pred_mask.device, requires_grad=True)
                    
                    self.loss_G = loss
                else:
                    # 非IOU损失处理
                    # 获取预测mask和目标的形状
                    pred_shape = self.pred_mask.shape
                    
                    # 处理非标准维度
                    if len(pred_shape) == 5:  # 如果是[b,n,c,h,w]格式
                        b, n, c, h, w = pred_shape
                        # 重新整形为4D张量
                        self.pred_mask = self.pred_mask.view(b*n, c, h, w)
                        pred_shape = self.pred_mask.shape  # 更新形状
                    elif len(pred_shape) != 4:
                        print(f"警告：pred_mask形状异常 (非IOU分支): {pred_shape}")
                        if len(pred_shape) > 4:
                            # 从右侧取最后4个维度
                            self.pred_mask = self.pred_mask.reshape(-1, *pred_shape[-3:])
                        pred_shape = self.pred_mask.shape  # 更新形状
                        
                    gt_shape = self.gt_mask.shape[-2:]
                    
                    # 数值稳定性检查
                    self.pred_mask = torch.clamp(self.pred_mask, min=-100.0, max=100.0)
                    
                    # 如果形状不匹配，调整目标或预测
                    try:
                        if pred_shape[-2:] != gt_shape:
                            # 优先将目标下采样到预测的大小
                            gt_mask_resized = F.interpolate(
                                self.gt_mask, 
                                size=pred_shape[-2:],
                                mode="nearest"
                            )
                            self.loss_G = self.criterionBCE(self.pred_mask, gt_mask_resized)
                        else:
                            self.loss_G = self.criterionBCE(self.pred_mask, self.gt_mask)
                            
                        # 检查损失值
                        if torch.isnan(self.loss_G).any() or torch.isinf(self.loss_G).any():
                            print("警告：非IOU分支损失计算结果为NaN或Inf，使用零损失替代")
                            self.loss_G = torch.tensor(0.0, device=self.pred_mask.device, requires_grad=True)
                    except Exception as e:
                        print(f"非IOU分支损失计算出错: {e}")
                        # 创建零损失作为后备
                        self.loss_G = torch.tensor(0.0, device=self.pred_mask.device, requires_grad=True)
        except Exception as e:
            print(f"损失计算过程中发生异常: {e}")
            # 提供一个默认损失作为后备
            self.loss_G = torch.tensor(0.0, device=self.input.device, requires_grad=True)
            
        return self.loss_G

    def backward_G(self):
        """反向传播计算梯度"""
        self.loss_G.backward()

    def optimize_parameters(self, scaler):
        """执行完整的优化步骤（已被分解为forward、compute_loss等步骤）"""
        # 检查是否使用AMP
        use_amp = True
        if hasattr(self, 'use_amp'):
            use_amp = self.use_amp
        
        # 如果使用AMP (Automatic Mixed Precision)
        if use_amp and torch.cuda.is_available():
            from torch.cuda.amp import autocast
            
            if not hasattr(self, 'scaler'):
                self.scaler = scaler
            
            # 前向传播
            try:
                with autocast(enabled=True):
                    self.forward()
            except Exception as e:
                print(f"前向传播错误: {e}")
                # 创建一个零预测作为后备
                self.pred_mask = torch.zeros(
                    (self.input.shape[0], 5, self.inp_size, self.inp_size), 
                    device=self.input.device
                )
            
            # 确保预测中没有NaN
            if torch.isnan(self.pred_mask).any() or torch.isinf(self.pred_mask).any():
                print("优化器检测到预测中的NaN/Inf，进行修正")
                self.pred_mask = torch.nan_to_num(self.pred_mask, nan=0.0, posinf=0.0, neginf=0.0)
            
            # 确保ground truth中没有NaN
            if torch.isnan(self.gt_mask).any() or torch.isinf(self.gt_mask).any():
                print("优化器检测到ground truth中的NaN/Inf，进行修正")
                self.gt_mask = torch.nan_to_num(self.gt_mask, nan=0.0, posinf=0.0, neginf=0.0)
            
            # 损失计算
            try:
                with autocast(enabled=True):
                    b, c, h, w = self.pred_mask.shape
                    
                    # 调整ground truth到预测大小
                    gt_mask_downsampled = F.interpolate(
                        self.gt_mask, 
                        size=(h, w),
                        mode="nearest"
                    )
                    
                    # 获取类别索引
                    gt_indices = torch.argmax(gt_mask_downsampled, dim=1, keepdim=False)
                    
                    # 应用数值裁剪
                    self.pred_mask = torch.clamp(self.pred_mask, min=-100.0, max=100.0)
                    
                    # 使用交叉熵损失
                    loss = self.criterionBCE(self.pred_mask, gt_indices)
                    
                    # 检查损失是否为NaN
                    if torch.isnan(loss).any() or torch.isinf(loss).any():
                        print("损失计算得到NaN/Inf，使用零损失替代")
                        loss = torch.tensor(0.0, device=self.pred_mask.device, requires_grad=True)
                    
                    self.loss_G = loss
            except Exception as e:
                print(f"损失计算错误: {e}")
                # 创建一个零损失作为后备
                self.loss_G = torch.tensor(0.0, device=self.input.device, requires_grad=True)
            
            # 优化步骤
            try:
                self.optimizer.zero_grad()
                scaler.scale(self.loss_G).backward()
                
                # 在step之前unscale梯度
                scaler.unscale_(self.optimizer)
                
                # 梯度裁剪
                torch.nn.utils.clip_grad_norm_(self.parameters(), max_norm=1.0)
                
                # 检查参数的梯度是否有NaN
                for name, param in self.named_parameters():
                    if param.grad is not None and (torch.isnan(param.grad).any() or torch.isinf(param.grad).any()):
                        print(f"参数 {name} 的梯度包含NaN/Inf，设置为零")
                        param.grad = torch.zeros_like(param.grad)
                
                scaler.step(self.optimizer)
                scaler.update()
            except Exception as e:
                print(f"优化步骤错误: {e}")
                # 跳过当前优化步骤
        else:
            # 非AMP训练流程
            try:
                self.forward()
                
                # 确保预测中没有NaN
                if torch.isnan(self.pred_mask).any() or torch.isinf(self.pred_mask).any():
                    print("非AMP模式：预测中包含NaN/Inf，进行修正")
                    self.pred_mask = torch.nan_to_num(self.pred_mask, nan=0.0, posinf=0.0, neginf=0.0)
                
                # 计算损失
                b, c, h, w = self.pred_mask.shape
                
                # 调整ground truth到预测大小
                gt_mask_downsampled = F.interpolate(
                    self.gt_mask, 
                    size=(h, w),
                    mode="nearest"
                )
                
                # 获取类别索引
                gt_indices = torch.argmax(gt_mask_downsampled, dim=1, keepdim=False)
                
                # 应用数值裁剪
                self.pred_mask = torch.clamp(self.pred_mask, min=-100.0, max=100.0)
                
                # 使用交叉熵损失
                self.loss_G = self.criterionBCE(self.pred_mask, gt_indices)
                
                # 检查损失是否为NaN
                if torch.isnan(self.loss_G).any() or torch.isinf(self.loss_G).any():
                    print("非AMP模式：损失为NaN/Inf，使用零损失替代")
                    self.loss_G = torch.tensor(0.0, device=self.pred_mask.device, requires_grad=True)
                
                # 优化
                self.optimizer.zero_grad()
                self.loss_G.backward()
                
                # 梯度裁剪
                torch.nn.utils.clip_grad_norm_(self.parameters(), max_norm=1.0)
                
                # 检查梯度是否为NaN
                for name, param in self.named_parameters():
                    if param.grad is not None and (torch.isnan(param.grad).any() or torch.isinf(param.grad).any()):
                        print(f"非AMP模式：参数 {name} 的梯度包含NaN/Inf，设置为零")
                        param.grad = torch.zeros_like(param.grad)
                
                self.optimizer.step()
            except Exception as e:
                print(f"非AMP训练流程错误: {e}")
                # 跳过当前优化步骤

    def infer(self, input):
        bs = 1

        # Embed prompts
        sparse_embeddings = torch.empty(
            (bs, 0, self.prompt_embed_dim), device=input.device
        )
        dense_embeddings = self.no_mask_embed.weight.reshape(1, -1, 1, 1).expand(
            bs, -1, self.image_embedding_size, self.image_embedding_size
        )

        self.features = self.image_encoder(input)  # 第一个val 第二张图推理循环 显存+5G

        # Predict masks
        low_res_masks, iou_predictions = self.mask_decoder(
            image_embeddings=self.features,
            image_pe=self.get_dense_pe(),
            sparse_prompt_embeddings=sparse_embeddings,
            dense_prompt_embeddings=dense_embeddings,
            multimask_output=False,
        )

        # Upscale the masks to the original image resolution
        masks = self.postprocess_masks(low_res_masks, self.inp_size, self.inp_size)
        # masks_rgb= onehot_to_mask(masks)
        return masks

    def postprocess_masks(
        self,
        masks: torch.Tensor,
        input_size: Tuple[int, ...],
        original_size: Tuple[int, ...],
    ) -> torch.Tensor:
        """
        Remove padding and upscale masks to the original image size.

        Arguments:
          masks (torch.Tensor): Batched masks from the mask_decoder,
            in BxCxHxW format.
          input_size (tuple(int, int)): The size of the image input to the
            model, in (H, W) format. Used to remove padding.
          original_size (tuple(int, int)): The original size of the image
            before resizing for input to the model, in (H, W) format.

        Returns:
          (torch.Tensor): Batched masks in BxCxHxW format, where (H, W)
            is given by original_size.
        """
        # 安全检查：确保输入没有NaN
        if torch.isnan(masks).any() or torch.isinf(masks).any():
            print("警告：掩码后处理前检测到NaN，进行修正")
            masks = torch.nan_to_num(masks, nan=0.0, posinf=0.0, neginf=0.0)
        
        try:
            # masks = masks[0]
            masks = masks.squeeze(dim=1)
            
            # 数值稳定性检查
            masks = torch.clamp(masks, min=-100.0, max=100.0)
            
            # 上采样到编码器图像大小
            masks = F.interpolate(
                masks,
                (self.image_encoder.img_size, self.image_encoder.img_size),
                mode="bilinear",
                align_corners=False,
            )
            
            # 检查上采样是否产生NaN
            if torch.isnan(masks).any() or torch.isinf(masks).any():
                print("警告：第一次上采样后检测到NaN，进行修正")
                masks = torch.nan_to_num(masks, nan=0.0, posinf=0.0, neginf=0.0)
            
            # 裁剪到输入大小
            masks = masks[..., :input_size, :input_size]
            
            # 上采样到原始图像大小
            masks = F.interpolate(
                masks, original_size, mode="bilinear", align_corners=False
            )
            
            # 最终检查
            if torch.isnan(masks).any() or torch.isinf(masks).any():
                print("警告：最终上采样后检测到NaN，进行修正")
                masks = torch.nan_to_num(masks, nan=0.0, posinf=0.0, neginf=0.0)
                
            return masks
        except Exception as e:
            print(f"掩码后处理错误: {e}")
            # 创建一个零掩码作为后备
            output_shape = (masks.shape[0], masks.shape[1], original_size[0], original_size[1])
            return torch.zeros(output_shape, device=masks.device)

    def get_ignore_mask_loss(self, loss, ignore_index: list = None):
        """Create a mask to ignore certain pixels in the ground truth."""
        # 创建一个掩码
        mask = torch.ones_like(loss, device=loss.device)

        # 对于每个要屏蔽的类别，将掩码设置为0
        for index in ignore_index:
            mask[torch.argmax(self.gt_mask, dim=1) == index] = 0

        # 应用掩码到损失上
        loss = loss * mask
        return loss.sum() / torch.ones_like(loss, device=loss.device).sum()



    def set_requires_grad(self, nets, requires_grad=False):
        """Set requies_grad=Fasle for all the networks to avoid unnecessary computations
        Parameters:
            nets (network list)   -- a list of networks
            requires_grad (bool)  -- whether the networks require gradients or not
        """
        if not isinstance(nets, list):
            nets = [nets]
        for net in nets:
            if net is not None:
                for param in net.parameters():
                    param.requires_grad = requires_grad

@register('sam_moe')
class SAM_MOE(nn.Module):
    def __init__(
        self,
        inp_size=None,
        encoder_mode=None,
        loss=None,
        num_classes=None,
        loss_weight=None,
        ignore_index=-100,
    ):
        super().__init__()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.embed_dim = encoder_mode['embed_dim']
        
        # 添加混合精度训练的标志，默认启用
        self.use_amp = True
        
        self.image_encoder = ImageEncoderViT_moe(
            img_size=inp_size,
            patch_size=encoder_mode['patch_size'],
            in_chans=3,
            embed_dim=encoder_mode['embed_dim'],
            depth=encoder_mode['depth'],
            num_heads=encoder_mode['num_heads'],
            mlp_ratio=encoder_mode['mlp_ratio'],
            out_chans=encoder_mode['out_chans'],
            qkv_bias=encoder_mode['qkv_bias'],
            norm_layer=partial(torch.nn.LayerNorm, eps=1e-6),
            act_layer=nn.GELU,
            use_rel_pos=encoder_mode['use_rel_pos'],
            rel_pos_zero_init=True,
            window_size=encoder_mode['window_size'],
            global_attn_indexes=encoder_mode['global_attn_indexes'],
            moe_num_experts=23,
            moe_k=2,
            moe_noisy_gating=True,
        )
        self.prompt_embed_dim = encoder_mode['prompt_embed_dim']
        self.mask_decoder = MaskDecoder_moe(
            num_multimask_outputs=3,
            transformer=TwoWayTransformer_moe(
                depth=2,
                embedding_dim=self.prompt_embed_dim,
                mlp_dim=2048,
                num_heads=8,
            ),
            transformer_dim=self.prompt_embed_dim,
            iou_head_depth=3,
            iou_head_hidden_dim=256,
            num_classes=num_classes,
        )

        if 'evp' in encoder_mode['name']:
            for k, p in self.encoder.named_parameters():
                if (
                    "prompt" not in k
                    and "mask_decoder" not in k
                    and "prompt_encoder" not in k
                ):
                    p.requires_grad = False

        self.loss_mode = loss
        self.ignore_index = ignore_index

        if self.loss_mode == 'bce':
            self.criterionBCE = torch.nn.BCEWithLogitsLoss(reduction='none')

        elif self.loss_mode == 'bbce':
            self.criterionBCE = BBCEWithLogitLoss(reduction='none')

        elif self.loss_mode == 'iou':
            # self.criterionBCE = torch.nn.BCEWithLogitsLoss()
            # pos_weight = torch.tensor([1.5, 1, 0.5, 1.9, 0.1], dtype=torch.float)
            if loss_weight is not None:
                pos_weight = torch.tensor(loss_weight, dtype=torch.float)
                self.criterionBCE = torch.nn.CrossEntropyLoss(
                    pos_weight, ignore_index=self.ignore_index
                )
            else:
                self.criterionBCE = torch.nn.CrossEntropyLoss(
                    ignore_index=self.ignore_index
                )

            self.criterionIOU = IOU()

        # elif self.loss_mode == 'iou_ce':
        #     self.criterionBCE =  torch.nn.CrossEntropyLoss()
        #     self.criterionIOU = IOU()

        self.pe_layer = PositionEmbeddingRandom(encoder_mode['prompt_embed_dim'] // 2)
        self.inp_size = inp_size
        self.image_embedding_size = inp_size // encoder_mode['patch_size']
        self.no_mask_embed = nn.Embedding(1, encoder_mode['prompt_embed_dim'])

    def set_input(self, input, gt_mask):
        self.input = input.to(self.device)
        self.gt_mask = gt_mask.to(self.device)

    def get_dense_pe(self) -> torch.Tensor:
        """
        Returns the positional encoding used to encode point prompts,
        applied to a dense set of points the shape of the image encoding.

        Returns:
          torch.Tensor: Positional encoding with shape
            1x(embed_dim)x(embedding_h)x(embedding_w)
        """
        return self.pe_layer(self.image_embedding_size).unsqueeze(0)

    def forward(self):
        """前向传播，计算预测结果但不计算损失"""
        features = self.image_encoder(self.input)
        dense_embeddings = features
        bs = dense_embeddings.shape[0]

        output_masks = []
        for i in range(bs):
            this_dense_embeddings = dense_embeddings[i].unsqueeze(0)
            sparse_embeddings, dense_embeddings_ = this_dense_embeddings, this_dense_embeddings
            low_res_masks, iou_predictions = self.mask_decoder(
                image_embeddings=this_dense_embeddings,
                image_pe=self.get_dense_pe(),
                sparse_prompt_embeddings=sparse_embeddings,
                dense_prompt_embeddings=dense_embeddings_,
                multimask_output=False,
            )
            output_masks.append(low_res_masks)

        self.pred_mask = torch.cat(output_masks, dim=0)
        return self.pred_mask

    def compute_loss(self):
        """计算损失但不执行优化步骤"""
        if self.loss_mode == 'iou':
            # 检查pred_mask的实际维度
            pred_shape = self.pred_mask.shape
            
            # 根据pred_mask的实际维度进行处理
            # 对于5维张量(b,n,c,h,w)或其他非标准情况
            if len(pred_shape) == 5:  # 如果是[b,n,c,h,w]格式
                b, n, c, h, w = pred_shape
                # 重新整形为4D张量以便于处理
                self.pred_mask = self.pred_mask.view(b*n, c, h, w)
            elif len(pred_shape) != 4:
                # 其他异常情况，打印形状以便调试
                print(f"WARNING: Unexpected pred_mask shape: {pred_shape}")
                # 尝试适应不同的形状
                if len(pred_shape) > 4:
                    # 从右侧取最后4个维度
                    self.pred_mask = self.pred_mask.reshape(-1, *pred_shape[-3:])
                
            # 获取调整后的形状
            b, c, h, w = self.pred_mask.shape
            
            # 将目标从高分辨率(1024x1024)下采样到预测的分辨率(256x256)
            gt_mask_downsampled = F.interpolate(
                self.gt_mask, 
                size=(h, w),
                mode="nearest"
            )
            
            # 获取类别索引，而不是one-hot编码
            gt_indices = torch.argmax(gt_mask_downsampled, dim=1, keepdim=False)
            
            # 应用交叉熵损失
            loss = self.criterionBCE(
                self.pred_mask, gt_indices
            )
            self.loss_G = loss
        else:
            # 获取预测mask和目标的形状
            pred_shape = self.pred_mask.shape
            
            # 处理非标准维度
            if len(pred_shape) == 5:  # 如果是[b,n,c,h,w]格式
                b, n, c, h, w = pred_shape
                # 重新整形为4D张量
                self.pred_mask = self.pred_mask.view(b*n, c, h, w)
                pred_shape = self.pred_mask.shape  # 更新形状
            elif len(pred_shape) != 4:
                print(f"WARNING: Unexpected pred_mask shape in else branch: {pred_shape}")
                # 尝试适应不同的形状
                if len(pred_shape) > 4:
                    # 从右侧取最后4个维度
                    self.pred_mask = self.pred_mask.reshape(-1, *pred_shape[-3:])
                pred_shape = self.pred_mask.shape  # 更新形状
                
            gt_shape = self.gt_mask.shape[-2:]
            
            # 如果形状不匹配，调整目标或预测
            if pred_shape[-2:] != gt_shape:
                # 优先将目标下采样到预测的大小
                gt_mask_resized = F.interpolate(
                    self.gt_mask, 
                    size=pred_shape[-2:],
                    mode="nearest"
                )
                self.loss_G = self.criterionBCE(self.pred_mask, gt_mask_resized)
            else:
                self.loss_G = self.criterionBCE(self.pred_mask, self.gt_mask)
        return self.loss_G

    def backward_G(self):
        """反向传播计算梯度"""
        self.loss_G.backward()

    def optimize_parameters(self):
        """执行完整的优化步骤（已被分解为forward、compute_loss等步骤）"""
        # 检查是否使用AMP
        use_amp = True
        if hasattr(self, 'use_amp'):
            use_amp = self.use_amp
        
        # 如果使用AMP (Automatic Mixed Precision)
        if use_amp and torch.cuda.is_available():
            from torch.cuda.amp import autocast, GradScaler
            
            if not hasattr(self, 'scaler'):
                self.scaler = GradScaler()
            
            # 前向传播和损失计算在autocast环境中
            with autocast():
                self.forward()
                loss = self.compute_loss()
            
            # 使用scaler进行梯度缩放、反向传播和优化
            self.optimizer.zero_grad()
            self.scaler.scale(loss).backward()

            # 在step之前unscale梯度
            self.scaler.unscale_(self.optimizer)

            # 添加梯度裁剪
            torch.nn.utils.clip_grad_norm_(self.parameters(), max_norm=1.0) # max_norm=1.0 是一个常用值，可以调整

            self.scaler.step(self.optimizer)
            self.scaler.update()
        else:
            # 常规训练流程 (非 AMP)
            self.forward()
            loss = self.compute_loss() # 计算损失
            self.optimizer.zero_grad()
            # self.compute_loss()
            self.backward_G() # 反向传播
            # 如果不用AMP也需要梯度裁剪，可以在这里加
            # torch.nn.utils.clip_grad_norm_(self.parameters(), max_norm=1.0)
            self.optimizer.step()

    def infer(self, input):
        bs = 1

        # Embed prompts
        sparse_embeddings = torch.empty(
            (bs, 0, self.prompt_embed_dim), device=input.device
        )
        dense_embeddings = self.no_mask_embed.weight.reshape(1, -1, 1, 1).expand(
            bs, -1, self.image_embedding_size, self.image_embedding_size
        )

        self.features = self.image_encoder(input)  # 第一个val 第二张图推理循环 显存+5G

        # Predict masks
        low_res_masks, iou_predictions = self.mask_decoder(
            image_embeddings=self.features,
            image_pe=self.get_dense_pe(),
            sparse_prompt_embeddings=sparse_embeddings,
            dense_prompt_embeddings=dense_embeddings,
            multimask_output=False,
        )

        # Upscale the masks to the original image resolution
        masks = self.postprocess_masks(low_res_masks, self.inp_size, self.inp_size)
        # masks_rgb= onehot_to_mask(masks)
        return masks

    def postprocess_masks(
        self,
        masks: torch.Tensor,
        input_size: Tuple[int, ...],
        original_size: Tuple[int, ...],
    ) -> torch.Tensor:
        """
        Remove padding and upscale masks to the original image size.

        Arguments:
          masks (torch.Tensor): Batched masks from the mask_decoder,
            in BxCxHxW format.
          input_size (tuple(int, int)): The size of the image input to the
            model, in (H, W) format. Used to remove padding.
          original_size (tuple(int, int)): The original size of the image
            before resizing for input to the model, in (H, W) format.

        Returns:
          (torch.Tensor): Batched masks in BxCxHxW format, where (H, W)
            is given by original_size.
        """
        # masks = masks[0]
        masks = masks.squeeze(dim=1)
        masks = F.interpolate(
            masks,
            (self.image_encoder.img_size, self.image_encoder.img_size),
            mode="bilinear",
            align_corners=False,
        )
        masks = masks[..., :input_size, :input_size]
        masks = F.interpolate(
            masks, original_size, mode="bilinear", align_corners=False
        )
        return masks

    def get_ignore_mask_loss(self, loss, ignore_index: list = None):
        """Create a mask to ignore certain pixels in the ground truth."""
        # 创建一个掩码
        mask = torch.ones_like(loss, device=loss.device)

        # 对于每个要屏蔽的类别，将掩码设置为0
        for index in ignore_index:
            mask[torch.argmax(self.gt_mask, dim=1) == index] = 0

        # 应用掩码到损失上
        loss = loss * mask
        return loss.sum() / torch.ones_like(loss, device=loss.device).sum()



    def set_requires_grad(self, nets, requires_grad=False):
        """Set requies_grad=Fasle for all the networks to avoid unnecessary computations
        Parameters:
            nets (network list)   -- a list of networks
            requires_grad (bool)  -- whether the networks require gradients or not
        """
        if not isinstance(nets, list):
            nets = [nets]
        for net in nets:
            if net is not None:
                for param in net.parameters():
                    param.requires_grad = requires_grad

@register('sam_h')
class SAM_h(nn.Module):
    def __init__(
        self,
        inp_size=None,
        encoder_mode=None,
        loss=None,
        num_classes=None,
        loss_weight=None,
        ignore_index=-100,
    ):
        super().__init__()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.embed_dim = encoder_mode['embed_dim']
        self.inp_size = inp_size

        # 原始SAM的image encoder
        self.image_encoder = ImageEncoderViT(
            img_size=inp_size,
            patch_size=encoder_mode['patch_size'],
            in_chans=3,
            embed_dim=encoder_mode['embed_dim'],
            depth=encoder_mode['depth'],
            num_heads=encoder_mode['num_heads'],
            mlp_ratio=encoder_mode['mlp_ratio'],
            out_chans=encoder_mode['out_chans'],
            qkv_bias=encoder_mode['qkv_bias'],
            norm_layer=partial(torch.nn.LayerNorm, eps=1e-6),
            act_layer=nn.GELU,
            use_rel_pos=encoder_mode['use_rel_pos'],
            rel_pos_zero_init=True,
            window_size=encoder_mode['window_size'],
            global_attn_indexes=encoder_mode['global_attn_indexes'],
        )

        # 确保输入尺寸能被patch_size整除
        self.vit_input_size = (inp_size // 14) * 14  # 向下取整到最近的能被14整除的数

        # 计算需要的位置编码数量
        num_patches = (self.vit_input_size // 14) * (
            self.vit_input_size // 14
        ) + 1  # +1 for cls token

        # 初始化自定义的ViT-Huge
        self.vit_huge = vit_h_14(
            image_size=self.vit_input_size,  # 使用调整后的尺寸
            num_classes=0,
            pos_embed_size=num_patches,
        )
        self.vit_huge.heads = nn.Identity()  # 移除分类头

        # 加载预训练权重并处理
        VIT_HUGE_WEIGHTS_PATH = (
            '/public/home/daiwenxuan/project/fan/weights/vit_h_14_swag-80465313.pth'
        )
        if os.path.exists(VIT_HUGE_WEIGHTS_PATH):
            state_dict = torch.load(VIT_HUGE_WEIGHTS_PATH)

            # 移除不需要的权重
            state_dict.pop('heads.head.weight', None)
            state_dict.pop('heads.head.bias', None)

            # 处理位置编码
            orig_pos_embed = state_dict['encoder.pos_embedding']
            orig_pos_cls, orig_pos_patches = (
                orig_pos_embed[:, :1, :],
                orig_pos_embed[:, 1:, :],
            )

            # 计算grid sizes
            orig_grid_size = int(math.sqrt(orig_pos_patches.shape[1]))
            new_grid_size = inp_size // 14

            if orig_grid_size != new_grid_size:
                # 重塑并插值patch位置编码
                orig_pos_patches = orig_pos_patches.reshape(
                    1, orig_grid_size, orig_grid_size, -1
                )
                orig_pos_patches = orig_pos_patches.permute(0, 3, 1, 2)
                new_pos_patches = F.interpolate(
                    orig_pos_patches,
                    size=(new_grid_size, new_grid_size),
                    mode='bicubic',
                    align_corners=False,
                )
                new_pos_patches = new_pos_patches.permute(0, 2, 3, 1)
                new_pos_patches = new_pos_patches.reshape(
                    1, new_grid_size * new_grid_size, -1
                )
                new_pos_embed = torch.cat([orig_pos_cls, new_pos_patches], dim=1)
                state_dict['encoder.pos_embedding'] = new_pos_embed

            # 加载处理后的权重
            msg = self.vit_huge.load_state_dict(state_dict, strict=False)
            print("Successfully loaded ViT-Huge weights from:", VIT_HUGE_WEIGHTS_PATH)
            print("Loading message:", msg)
        else:
            print("Warning: ViT-Huge weights not found at:", VIT_HUGE_WEIGHTS_PATH)

        # 特征适配层
        self.huge_adapter = nn.Sequential(
            nn.Conv2d(1280, encoder_mode['out_chans'], 1),
            nn.BatchNorm2d(encoder_mode['out_chans']),
            nn.ReLU(),
        )

        self.prompt_embed_dim = encoder_mode['prompt_embed_dim']
        self.mask_decoder = MaskDecoder(
            num_multimask_outputs=3,
            transformer=TwoWayTransformer(
                depth=2,
                embedding_dim=self.prompt_embed_dim,
                mlp_dim=2048,
                num_heads=8,
            ),
            transformer_dim=self.prompt_embed_dim,
            iou_head_depth=3,
            iou_head_hidden_dim=256,
            num_classes=num_classes,
        )

        if 'evp' in encoder_mode['name']:
            for k, p in self.encoder.named_parameters():
                if (
                    "prompt" not in k
                    and "mask_decoder" not in k
                    and "prompt_encoder" not in k
                ):
                    p.requires_grad = False

        self.loss_mode = loss
        self.ignore_index = ignore_index

        if self.loss_mode == 'bce':
            self.criterionBCE = torch.nn.BCEWithLogitsLoss(reduction='none')

        elif self.loss_mode == 'bbce':
            self.criterionBCE = BBCEWithLogitLoss(reduction='none')

        elif self.loss_mode == 'iou':
            # self.criterionBCE = torch.nn.BCEWithLogitsLoss()
            # pos_weight = torch.tensor([1.5, 1, 0.5, 1.9, 0.1], dtype=torch.float)
            if loss_weight is not None:
                pos_weight = torch.tensor(loss_weight, dtype=torch.float)
                self.criterionBCE = torch.nn.CrossEntropyLoss(
                    pos_weight, ignore_index=self.ignore_index
                )
            else:
                self.criterionBCE = torch.nn.CrossEntropyLoss(
                    ignore_index=self.ignore_index
                )

            self.criterionIOU = IOU()

        # elif self.loss_mode == 'iou_ce':
        #     self.criterionBCE =  torch.nn.CrossEntropyLoss()
        #     self.criterionIOU = IOU()

        self.pe_layer = PositionEmbeddingRandom(encoder_mode['prompt_embed_dim'] // 2)
        self.inp_size = inp_size
        self.image_embedding_size = inp_size // encoder_mode['patch_size']
        self.no_mask_embed = nn.Embedding(1, encoder_mode['prompt_embed_dim'])

    def _process_vit_huge_features(self, x):
        """处理ViT-Huge的特征"""
        B = x.shape[0]

        # 调整输入大小为能被14整除的尺寸
        x_resized = F.interpolate(
            x,
            size=(self.vit_input_size, self.vit_input_size),
            mode='bilinear',
            align_corners=False,
        )

        # 获取patch embeddings
        x = self.vit_huge.conv_proj(x_resized)
        _, C, H, W = x.shape
        x = x.flatten(2).transpose(1, 2)

        # 添加class token
        cls_token = self.vit_huge.class_token.expand(B, -1, -1)
        x = torch.cat((cls_token, x), dim=1)

        # 添加位置编码
        x = x + self.vit_huge.encoder.pos_embedding

        # 通过encoder
        for blk in self.vit_huge.encoder.layers:
            x = blk(x)
        x = self.vit_huge.encoder.ln(x)

        # 移除class token并重塑为特征图
        x = x[:, 1:, :]
        x = x.reshape(B, H, W, -1).permute(0, 3, 1, 2)

        # 调整特征图大小以匹配SAM encoder的输出
        x = F.interpolate(
            x,
            size=(self.inp_size // 16, self.inp_size // 16),
            mode='bilinear',
            align_corners=False,
        )

        return self.huge_adapter(x)

    def set_input(self, input, gt_mask):
        self.input = input.to(self.device)
        self.gt_mask = gt_mask.to(self.device)

    def get_dense_pe(self) -> torch.Tensor:
        """
        Returns the positional encoding used to encode point prompts,
        applied to a dense set of points the shape of the image encoding.

        Returns:
          torch.Tensor: Positional encoding with shape
            1x(embed_dim)x(embedding_h)x(embedding_w)
        """
        return self.pe_layer(self.image_embedding_size).unsqueeze(0)

    def forward(self):
        bs = self.input.shape[0]

        # Embed prompts
        sparse_embeddings = torch.empty(
            (bs, 0, self.prompt_embed_dim), device=self.input.device
        )
        dense_embeddings = self.no_mask_embed.weight.reshape(1, -1, 1, 1).expand(
            bs, -1, self.image_embedding_size, self.image_embedding_size
        )

        # 获取两个encoder的特征
        sam_features = self.image_encoder(self.input)
        huge_features = self._process_vit_huge_features(self.input)

        # 特征融合（0.5的比例）
        self.features = 0.5 * sam_features + 0.5 * huge_features

        # Predict masks
        low_res_masks, iou_predictions = self.mask_decoder(
            image_embeddings=self.features,
            image_pe=self.get_dense_pe(),
            sparse_prompt_embeddings=sparse_embeddings,
            dense_prompt_embeddings=dense_embeddings,
            multimask_output=False,
        )

        # Upscale the masks to the original image resolution
        masks = self.postprocess_masks(low_res_masks, self.inp_size, self.inp_size)
        self.pred_mask = masks

    def infer(self, input):
        bs = 1

        # Embed prompts
        sparse_embeddings = torch.empty(
            (bs, 0, self.prompt_embed_dim), device=input.device
        )
        dense_embeddings = self.no_mask_embed.weight.reshape(1, -1, 1, 1).expand(
            bs, -1, self.image_embedding_size, self.image_embedding_size
        )

        # 获取两个encoder的特征
        sam_features = self.image_encoder(input)
        huge_features = self._process_vit_huge_features(input)

        # 特征融合（0.5的比例）
        self.features = 0.5 * sam_features + 0.5 * huge_features

        # Predict masks
        low_res_masks, iou_predictions = self.mask_decoder(
            image_embeddings=self.features,
            image_pe=self.get_dense_pe(),
            sparse_prompt_embeddings=sparse_embeddings,
            dense_prompt_embeddings=dense_embeddings,
            multimask_output=False,
        )

        # Upscale the masks to the original image resolution
        masks = self.postprocess_masks(low_res_masks, self.inp_size, self.inp_size)
        return masks

    def postprocess_masks(
        self,
        masks: torch.Tensor,
        input_size: Tuple[int, ...],
        original_size: Tuple[int, ...],
    ) -> torch.Tensor:
        """
        Remove padding and upscale masks to the original image size.

        Arguments:
          masks (torch.Tensor): Batched masks from the mask_decoder,
            in BxCxHxW format.
          input_size (tuple(int, int)): The size of the image input to the
            model, in (H, W) format. Used to remove padding.
          original_size (tuple(int, int)): The original size of the image
            before resizing for input to the model, in (H, W) format.

        Returns:
          (torch.Tensor): Batched masks in BxCxHxW format, where (H, W)
            is given by original_size.
        """
        # masks = masks[0]
        masks = masks.squeeze(dim=1)
        masks = F.interpolate(
            masks,
            (self.image_encoder.img_size, self.image_encoder.img_size),
            mode="bilinear",
            align_corners=False,
        )
        masks = masks[..., :input_size, :input_size]
        masks = F.interpolate(
            masks, original_size, mode="bilinear", align_corners=False
        )
        return masks

    def get_ignore_mask_loss(self, loss, ignore_index: list = None):
        """Create a mask to ignore certain pixels in the ground truth."""
        # 创建一个掩码
        mask = torch.ones_like(loss, device=loss.device)

        # 对于每个要屏蔽的类别，将掩码设置为0
        for index in ignore_index:
            mask[torch.argmax(self.gt_mask, dim=1) == index] = 0

        # 应用掩码到损失上
        loss = loss * mask
        return loss.sum() / torch.ones_like(loss, device=loss.device).sum()

    def backward_G(self):
        """Calculate GAN and L1 loss for the generator"""
        # mask = self.create_ignore_mask(self.gt_mask, ignore_index=self.ignore_index)

        loss = self.criterionBCE(
            self.pred_mask, torch.argmax(self.gt_mask, dim=1, keepdim=True).squeeze(1)
        )  # (1,4,1024,1024)
        # print(
        #     f'未忽略类别loss:{self.criterionBCE(self.pred_mask, self.gt_mask).mean()}'
        # )
        # guanfang_crt = torch.nn.CrossEntropyLoss(ignore_index=0)
        # guanfang_loss = guanfang_crt(
        #     self.pred_mask, torch.argmax(self.gt_mask, dim=1, keepdim=True).squeeze(1)
        # )
        # print(f'guanfang忽略类别loss:{guanfang_loss}')
        # loss = self.get_ignore_mask_loss(loss, ignore_index=self.ignore_index)
        # print(f'忽略类别loss:{loss}')

        # loss = loss * mask  # 应用掩码
        # loss = loss.sum() / mask.sum()  # 仅计算非忽略像素的损失
        self.loss_G = loss
        # if self.loss_mode == 'iou':
        # self.loss_G += _iou_loss(self.pred_mask, self.gt_mask)

        self.loss_G.backward()

    def optimize_parameters(self):
        self.forward()
        self.optimizer.zero_grad()  # set G's gradients to zero
        self.backward_G()  # calculate graidents for G
        self.optimizer.step()  # udpate G's weights

    def set_requires_grad(self, nets, requires_grad=False):
        """Set requies_grad=Fasle for all the networks to avoid unnecessary computations
        Parameters:
            nets (network list)   -- a list of networks
            requires_grad (bool)  -- whether the networks require gradients or not
        """
        if not isinstance(nets, list):
            nets = [nets]
        for net in nets:
            if net is not None:
                for param in net.parameters():
                    param.requires_grad = requires_grad


@register('sam_b_l')
class SAM_b_l(nn.Module):
    def __init__(
        self,
        inp_size=None,
        encoder_mode=None,
        loss=None,
        num_classes=None,
        loss_weight=None,
    ):
        super().__init__()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.embed_dim = encoder_mode['embed_dim']

        # vit-huge encoder (SAM原始encoder)
        self.image_encoder = ImageEncoderViT(
            img_size=inp_size,
            patch_size=encoder_mode['patch_size'],
            in_chans=3,
            embed_dim=encoder_mode['embed_dim'],
            depth=encoder_mode['depth'],
            num_heads=encoder_mode['num_heads'],
            mlp_ratio=encoder_mode['mlp_ratio'],
            out_chans=encoder_mode['out_chans'],
            qkv_bias=encoder_mode['qkv_bias'],
            norm_layer=partial(torch.nn.LayerNorm, eps=1e-6),
            act_layer=nn.GELU,
            use_rel_pos=encoder_mode['use_rel_pos'],
            rel_pos_zero_init=True,
            window_size=encoder_mode['window_size'],
            global_attn_indexes=encoder_mode['global_attn_indexes'],
        )
        # # 指定预训练权重的本地路径
        # BASE_WEIGHT_PATH = '/public/home/daiwenxuan/project/fan/cwsam/model_data/vit_base.pth'
        # LARGE_WEIGHT_PATH = '/public/home/daiwenxuan/project/fan/cwsam/model_data/vit_large.pth'
        # # 使用timm的预训练ViT-Base模型
        # self.base_encoder = timm.create_model(
        #     'vit_base_patch16_224',
        #     pretrained=False,
        #     num_classes=0,  # 移除分类头
        # )
        # if os.path.exists(BASE_WEIGHT_PATH):
        #     self.base_encoder.load_state_dict(torch.load(BASE_WEIGHT_PATH))
        # # 使用timm的预训练ViT-Large模型
        # self.large_encoder = timm.create_model(
        #     'vit_large_patch16_224',
        #     pretrained=False,
        #     num_classes=0,  # 移除分类头
        # )
        # if os.path.exists(LARGE_WEIGHT_PATH):
        #     self.large_encoder.load_state_dict(torch.load(LARGE_WEIGHT_PATH))
        # 添加特征适配层，将base和large的特征维度调整为与huge相同
        # 使用transformers的预训练ViT-Base模型
        # self.base_encoder = ViTModel.from_pretrained('google/vit-base-patch16-224')

        # 使用transformers的预训练ViT-Large模型
        # self.large_encoder = ViTModel.from_pretrained('google/vit-large-patch16-224')

        # 初始化不带预训练权重的模型
        self.base_encoder = vit_b_16(weights=None)
        self.base_encoder.heads = nn.Identity()

        self.large_encoder = vit_l_16(weights=None)
        self.large_encoder.heads = nn.Identity()

        # 指定预训练权重文件路径
        VIT_BASE_WEIGHTS_PATH = '/public/home/daiwenxuan/project/fan/cwsam/model_data/vit_b_16-c867db91.pth'  # 替换为实际的权重文件路径
        VIT_LARGE_WEIGHTS_PATH = '/public/home/daiwenxuan/project/fan/cwsam/model_data/vit_l_16-852ce7e3.pth'  # 替换为实际的权重文件路径
        # 添加特征适配层，将base和large的特征维度调整为与huge相同
        # 修改特征适配层
        self.base_adapter = nn.Sequential(
            nn.Conv2d(768, encoder_mode['out_chans'], 1),
            nn.BatchNorm2d(encoder_mode['out_chans']),
            nn.ReLU(),
        )

        self.large_adapter = nn.Sequential(
            nn.Conv2d(1024, encoder_mode['out_chans'], 1),
            nn.BatchNorm2d(encoder_mode['out_chans']),
            nn.ReLU(),
        )
        self.prompt_embed_dim = encoder_mode['prompt_embed_dim']
        self.mask_decoder = MaskDecoder(
            num_multimask_outputs=3,
            transformer=TwoWayTransformer(
                depth=2,
                embedding_dim=self.prompt_embed_dim,
                mlp_dim=2048,
                num_heads=8,
            ),
            transformer_dim=self.prompt_embed_dim,
            iou_head_depth=3,
            iou_head_hidden_dim=256,
            num_classes=num_classes,
        )

        if 'evp' in encoder_mode['name']:
            for k, p in self.encoder.named_parameters():
                if (
                    "prompt" not in k
                    and "mask_decoder" not in k
                    and "prompt_encoder" not in k
                ):
                    p.requires_grad = False

        self.loss_mode = loss

        if self.loss_mode == 'bce':
            self.criterionBCE = torch.nn.BCEWithLogitsLoss()

        elif self.loss_mode == 'bbce':
            self.criterionBCE = BBCEWithLogitLoss()

        elif self.loss_mode == 'iou':
            # self.criterionBCE = torch.nn.BCEWithLogitsLoss()
            # pos_weight = torch.tensor([1.5, 1, 0.5, 1.9, 0.1], dtype=torch.float)
            if loss_weight is not None:
                pos_weight = torch.tensor(loss_weight, dtype=torch.float)
                self.criterionBCE = torch.nn.CrossEntropyLoss(pos_weight)
            else:
                self.criterionBCE = torch.nn.CrossEntropyLoss()

            self.criterionIOU = IOU()

        # elif self.loss_mode == 'iou_ce':
        #     self.criterionBCE =  torch.nn.CrossEntropyLoss()
        #     self.criterionIOU = IOU()

        self.pe_layer = PositionEmbeddingRandom(encoder_mode['prompt_embed_dim'] // 2)
        self.inp_size = inp_size
        self.image_embedding_size = inp_size // encoder_mode['patch_size']
        self.no_mask_embed = nn.Embedding(1, encoder_mode['prompt_embed_dim'])

    def set_input(self, input, gt_mask):
        self.input = input.to(self.device)
        self.gt_mask = gt_mask.to(self.device)

    def get_dense_pe(self) -> torch.Tensor:
        """
        Returns the positional encoding used to encode point prompts,
        applied to a dense set of points the shape of the image encoding.

        Returns:
          torch.Tensor: Positional encoding with shape
            1x(embed_dim)x(embedding_h)x(embedding_w)
        """
        return self.pe_layer(self.image_embedding_size).unsqueeze(0)

    def _process_base_features(self, x):
        # 1. 首先将输入调整为224x224
        x_resized = F.interpolate(
            x, size=(224, 224), mode='bilinear', align_corners=False
        )

        # 2. 获取patch embeddings
        x = self.base_encoder.conv_proj(x_resized)
        B, C, H, W = x.shape

        # 3. 处理位置编码和特征
        x = x.flatten(2).transpose(1, 2)

        # 添加[CLS]标记
        cls_token = self.base_encoder.class_token.expand(B, -1, -1)
        x = torch.cat((cls_token, x), dim=1)

        # 添加位置编码 - 使用encoder中的pos_embedding
        x = x + self.base_encoder.encoder.pos_embedding

        # 通过encoder的layers
        for blk in self.base_encoder.encoder.layers:
            x = blk(x)
        x = self.base_encoder.encoder.ln(x)

        # 移除[CLS]标记
        x = x[:, 1:, :]

        # 4. 重塑为特征图并上采样到原始大小
        x = x.reshape(
            B, int(math.sqrt(x.shape[1])), int(math.sqrt(x.shape[1])), -1
        ).permute(0, 3, 1, 2)
        x = F.interpolate(
            x,
            size=(self.inp_size // 16, self.inp_size // 16),
            mode='bilinear',
            align_corners=False,
        )

        # 5. 通过适配层调整通道数
        return self.base_adapter(x)

    def _process_large_features(self, x):
        # 1. 首先将输入调整为224x224
        x_resized = F.interpolate(
            x, size=(224, 224), mode='bilinear', align_corners=False
        )

        # 2. 获取patch embeddings
        x = self.large_encoder.conv_proj(x_resized)
        B, C, H, W = x.shape

        # 3. 处理位置编码和特征
        x = x.flatten(2).transpose(1, 2)

        # 添加[CLS]标记
        cls_token = self.large_encoder.class_token.expand(B, -1, -1)
        x = torch.cat((cls_token, x), dim=1)

        # 添加位置编码 - 使用encoder中的pos_embedding
        x = x + self.large_encoder.encoder.pos_embedding

        # 通过encoder的layers
        for blk in self.large_encoder.encoder.layers:
            x = blk(x)
        x = self.large_encoder.encoder.ln(x)

        # 移除[CLS]标记
        x = x[:, 1:, :]

        # 4. 重塑为特征图并上采样到原始大小
        x = x.reshape(
            B, int(math.sqrt(x.shape[1])), int(math.sqrt(x.shape[1])), -1
        ).permute(0, 3, 1, 2)
        x = F.interpolate(
            x,
            size=(self.inp_size // 16, self.inp_size // 16),
            mode='bilinear',
            align_corners=False,
        )

        # 5. 通过适配层调整通道数
        return self.large_adapter(x)

    def forward(self):
        bs = self.input.shape[0]  # 应该是3
        # 获取三个encoder的特征
        huge_features = self.image_encoder(self.input)
        base_features = self._process_base_features(self.input)
        large_features = self._process_large_features(self.input)

        # 确保特征图大小一致并相加
        base_features = F.interpolate(
            base_features,
            size=huge_features.shape[-2:],
            mode='bilinear',
            align_corners=False,
        )
        large_features = F.interpolate(
            large_features,
            size=huge_features.shape[-2:],
            mode='bilinear',
            align_corners=False,
        )
        self.features = huge_features + base_features + large_features
        # Embed prompts
        sparse_embeddings = torch.empty(
            (bs, 0, self.prompt_embed_dim), device=self.input.device
        )
        dense_embeddings = self.no_mask_embed.weight.reshape(1, -1, 1, 1).expand(
            bs, -1, self.image_embedding_size, self.image_embedding_size
        )

        # Predict masks
        low_res_masks, iou_predictions = self.mask_decoder(
            image_embeddings=self.features,
            image_pe=self.get_dense_pe(),
            sparse_prompt_embeddings=sparse_embeddings,
            dense_prompt_embeddings=dense_embeddings,
            multimask_output=False,
        )

        # 打印低分辨率掩码的形状
        # print(f"Low res masks shape: {low_res_masks.shape}")

        # Upscale the masks to the original image resolution
        masks = self.postprocess_masks(low_res_masks, self.inp_size, self.inp_size)
        self.pred_mask = masks

        # 打印最终预测掩码的形状
        # print(f"Final pred_mask shape: {self.pred_mask.shape}")

    def infer(self, input):
        bs = 1

        # 获取三个encoder的特征
        huge_features = self.image_encoder(input)
        base_features = self._process_base_features(input)
        large_features = self._process_large_features(input)

        # 确保特征图大小一致并相加
        base_features = F.interpolate(
            base_features,
            size=huge_features.shape[-2:],
            mode='bilinear',
            align_corners=False,
        )
        large_features = F.interpolate(
            large_features,
            size=huge_features.shape[-2:],
            mode='bilinear',
            align_corners=False,
        )
        self.features = huge_features + base_features + large_features

        # Embed prompts
        sparse_embeddings = torch.empty(
            (bs, 0, self.prompt_embed_dim), device=input.device
        )
        dense_embeddings = self.no_mask_embed.weight.reshape(1, -1, 1, 1).expand(
            bs, -1, self.image_embedding_size, self.image_embedding_size
        )

        # Predict masks
        low_res_masks, iou_predictions = self.mask_decoder(
            image_embeddings=self.features,
            image_pe=self.get_dense_pe(),
            sparse_prompt_embeddings=sparse_embeddings,
            dense_prompt_embeddings=dense_embeddings,
            multimask_output=False,
        )

        # Upscale the masks to the original image resolution
        masks = self.postprocess_masks(low_res_masks, self.inp_size, self.inp_size)
        # masks_rgb= onehot_to_mask(masks)
        return masks

    def postprocess_masks(
        self,
        masks: torch.Tensor,
        input_size: Tuple[int, ...],
        original_size: Tuple[int, ...],
    ) -> torch.Tensor:
        """
        Remove padding and upscale masks to the original image size.
        """
        # 打印输入形状以便调试
        # print(f"Masks shape before processing: {masks.shape}")

        # 处理5D张量 [B, 1, C, H, W] -> [B, C, H, W]
        if masks.dim() == 5:
            masks = masks.squeeze(1)

        # print(f"Masks shape after squeeze: {masks.shape}")

        # 确保维度顺序正确 [B, C, H, W]
        if masks.shape[1] > masks.shape[2]:  # 如果通道数大于高度
            masks = masks.permute(0, 2, 3, 1)  # [B, 34, 256, 256] -> [B, 256, 256, 34]
            masks = masks.contiguous()
            masks = masks.permute(0, 3, 1, 2)  # [B, 256, 256, 34] -> [B, 34, 256, 256]

        # print(f"Masks shape before interpolate: {masks.shape}")

        # 进行上采样
        masks = F.interpolate(
            masks,
            (self.image_encoder.img_size, self.image_encoder.img_size),
            mode="bilinear",
            align_corners=False,
        )

        # print(f"Masks shape after first interpolate: {masks.shape}")

        # 裁剪到输入大小
        masks = masks[..., :input_size, :input_size]

        # 上采样到原始大小
        masks = F.interpolate(
            masks, (original_size, original_size), mode="bilinear", align_corners=False
        )

        # print(f"Final masks shape: {masks.shape}")

        return masks

    def backward_G(self):
        """Calculate GAN and L1 loss for the generator"""
        # mask = self.create_ignore_mask(self.gt_mask, ignore_index=self.ignore_index)

        loss = self.criterionBCE(
            self.pred_mask, torch.argmax(self.gt_mask, dim=1, keepdim=True).squeeze(1)
        )  # (1,4,1024,1024)
        # print(
        #     f'未忽略类别loss:{self.criterionBCE(self.pred_mask, self.gt_mask).mean()}'
        # )
        # guanfang_crt = torch.nn.CrossEntropyLoss(ignore_index=0)
        # guanfang_loss = guanfang_crt(
        #     self.pred_mask, torch.argmax(self.gt_mask, dim=1, keepdim=True).squeeze(1)
        # )
        # print(f'guanfang忽略类别loss:{guanfang_loss}')
        # loss = self.get_ignore_mask_loss(loss, ignore_index=self.ignore_index)
        # print(f'忽略类别loss:{loss}')

        # loss = loss * mask  # 应用掩码
        # loss = loss.sum() / mask.sum()  # 仅计算非忽略像素的损失
        self.loss_G = loss
        # if self.loss_mode == 'iou':
        # self.loss_G += _iou_loss(self.pred_mask, self.gt_mask)

        # 移除自动执行的反向传播，由AMP代码处理
        # self.loss_G.backward()

    def optimize_parameters(self):
        self.forward()
        self.optimizer.zero_grad()  # set G's gradients to zero
        self.backward_G()  # calculate graidents for G
        self.optimizer.step()  # udpate G's weights

    def set_requires_grad(self, nets, requires_grad=False):
        """Set requies_grad=Fasle for all the networks to avoid unnecessary computations
        Parameters:
            nets (network list)   -- a list of networks
            requires_grad (bool)  -- whether the networks require gradients or not
        """
        if not isinstance(nets, list):
            nets = [nets]
        for net in nets:
            if net is not None:
                for param in net.parameters():
                    param.requires_grad = requires_grad


@register('sam_two_image_encoder')
class SAM_two_image_encoder(nn.Module):
    def __init__(
        self,
        inp_size=None,
        encoder_mode=None,
        loss=None,
        num_classes=None,
        loss_weight=None,
        ignore_index=-100,
    ):
        super().__init__()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.embed_dim = encoder_mode['embed_dim']
        self.image_encoder = ImageEncoderViT(
            img_size=inp_size,
            patch_size=encoder_mode['patch_size'],
            in_chans=3,
            embed_dim=encoder_mode['embed_dim'],
            depth=encoder_mode['depth'],
            num_heads=encoder_mode['num_heads'],
            mlp_ratio=encoder_mode['mlp_ratio'],
            out_chans=encoder_mode['out_chans'],
            qkv_bias=encoder_mode['qkv_bias'],
            norm_layer=partial(torch.nn.LayerNorm, eps=1e-6),
            act_layer=nn.GELU,
            use_rel_pos=encoder_mode['use_rel_pos'],
            rel_pos_zero_init=True,
            window_size=encoder_mode['window_size'],
            global_attn_indexes=encoder_mode['global_attn_indexes'],
        )
        self.image_encoder2 = ImageEncoderViT(
            img_size=inp_size,
            patch_size=encoder_mode['patch_size'],
            in_chans=3,
            embed_dim=encoder_mode['embed_dim'],
            depth=encoder_mode['depth'],
            num_heads=encoder_mode['num_heads'],
            mlp_ratio=encoder_mode['mlp_ratio'],
            out_chans=encoder_mode['out_chans'],
            qkv_bias=encoder_mode['qkv_bias'],
            norm_layer=partial(torch.nn.LayerNorm, eps=1e-6),
            act_layer=nn.GELU,
            use_rel_pos=encoder_mode['use_rel_pos'],
            rel_pos_zero_init=True,
            window_size=encoder_mode['window_size'],
            global_attn_indexes=encoder_mode['global_attn_indexes'],
        )
        self.prompt_embed_dim = encoder_mode['prompt_embed_dim']
        self.mask_decoder = MaskDecoder(
            num_multimask_outputs=3,
            transformer=TwoWayTransformer(
                depth=2,
                embedding_dim=self.prompt_embed_dim,
                mlp_dim=2048,
                num_heads=8,
            ),
            transformer_dim=self.prompt_embed_dim,
            iou_head_depth=3,
            iou_head_hidden_dim=256,
            num_classes=num_classes,
        )

        if 'evp' in encoder_mode['name']:
            for k, p in self.encoder.named_parameters():
                if (
                    "prompt" not in k
                    and "mask_decoder" not in k
                    and "prompt_encoder" not in k
                ):
                    p.requires_grad = False

        self.loss_mode = loss
        self.ignore_index = ignore_index

        if self.loss_mode == 'bce':
            self.criterionBCE = torch.nn.BCEWithLogitsLoss(reduction='none')

        elif self.loss_mode == 'bbce':
            self.criterionBCE = BBCEWithLogitLoss(reduction='none')

        elif self.loss_mode == 'iou':
            # self.criterionBCE = torch.nn.BCEWithLogitsLoss()
            # pos_weight = torch.tensor([1.5, 1, 0.5, 1.9, 0.1], dtype=torch.float)
            if loss_weight is not None:
                pos_weight = torch.tensor(loss_weight, dtype=torch.float)
                self.criterionBCE = torch.nn.CrossEntropyLoss(
                    pos_weight, ignore_index=self.ignore_index
                )
            else:
                self.criterionBCE = torch.nn.CrossEntropyLoss(
                    ignore_index=self.ignore_index
                )

            self.criterionIOU = IOU()

        # elif self.loss_mode == 'iou_ce':
        #     self.criterionBCE =  torch.nn.CrossEntropyLoss()
        #     self.criterionIOU = IOU()

        self.pe_layer = PositionEmbeddingRandom(encoder_mode['prompt_embed_dim'] // 2)
        self.inp_size = inp_size
        self.image_embedding_size = inp_size // encoder_mode['patch_size']
        self.no_mask_embed = nn.Embedding(1, encoder_mode['prompt_embed_dim'])

    def set_input(self, input, gt_mask):
        self.input = input.to(self.device)
        self.gt_mask = gt_mask.to(self.device)

    def get_dense_pe(self) -> torch.Tensor:
        """
        Returns the positional encoding used to encode point prompts,
        applied to a dense set of points the shape of the image encoding.

        Returns:
          torch.Tensor: Positional encoding with shape
            1x(embed_dim)x(embedding_h)x(embedding_w)
        """
        return self.pe_layer(self.image_embedding_size).unsqueeze(0)

    def forward(self):
        # bs = 1
        bs = self.input.shape[0]

        # Embed prompts
        sparse_embeddings = torch.empty(
            (bs, 0, self.prompt_embed_dim), device=self.input.device
        )
        dense_embeddings = self.no_mask_embed.weight.reshape(1, -1, 1, 1).expand(
            bs, -1, self.image_embedding_size, self.image_embedding_size
        )

        self.features = self.image_encoder(self.input)

        # Predict masks
        low_res_masks, iou_predictions = self.mask_decoder(
            image_embeddings=self.features,
            image_pe=self.get_dense_pe(),
            sparse_prompt_embeddings=sparse_embeddings,
            dense_prompt_embeddings=dense_embeddings,
            multimask_output=False,
        )

        # Upscale the masks to the original image resolution
        masks = self.postprocess_masks(low_res_masks, self.inp_size, self.inp_size)
        self.pred_mask = masks

    def infer(self, input):
        bs = 1

        # Embed prompts
        sparse_embeddings = torch.empty(
            (bs, 0, self.prompt_embed_dim), device=input.device
        )
        dense_embeddings = self.no_mask_embed.weight.reshape(1, -1, 1, 1).expand(
            bs, -1, self.image_embedding_size, self.image_embedding_size
        )

        self.features = self.image_encoder(input)  # 第一个val 第二张图推理循环 显存+5G

        # Predict masks
        low_res_masks, iou_predictions = self.mask_decoder(
            image_embeddings=self.features,
            image_pe=self.get_dense_pe(),
            sparse_prompt_embeddings=sparse_embeddings,
            dense_prompt_embeddings=dense_embeddings,
            multimask_output=False,
        )

        # Upscale the masks to the original image resolution
        masks = self.postprocess_masks(low_res_masks, self.inp_size, self.inp_size)
        # masks_rgb= onehot_to_mask(masks)
        return masks

    def postprocess_masks(
        self,
        masks: torch.Tensor,
        input_size: Tuple[int, ...],
        original_size: Tuple[int, ...],
    ) -> torch.Tensor:
        """
        Remove padding and upscale masks to the original image size.

        Arguments:
          masks (torch.Tensor): Batched masks from the mask_decoder,
            in BxCxHxW format.
          input_size (tuple(int, int)): The size of the image input to the
            model, in (H, W) format. Used to remove padding.
          original_size (tuple(int, int)): The original size of the image
            before resizing for input to the model, in (H, W) format.

        Returns:
          (torch.Tensor): Batched masks in BxCxHxW format, where (H, W)
            is given by original_size.
        """
        # masks = masks[0]
        masks = masks.squeeze(dim=1)
        masks = F.interpolate(
            masks,
            (self.image_encoder.img_size, self.image_encoder.img_size),
            mode="bilinear",
            align_corners=False,
        )
        masks = masks[..., :input_size, :input_size]
        masks = F.interpolate(
            masks, original_size, mode="bilinear", align_corners=False
        )
        return masks

    def get_ignore_mask_loss(self, loss, ignore_index: list = None):
        """Create a mask to ignore certain pixels in the ground truth."""
        # 创建一个掩码
        mask = torch.ones_like(loss, device=loss.device)

        # 对于每个要屏蔽的类别，将掩码设置为0
        for index in ignore_index:
            mask[torch.argmax(self.gt_mask, dim=1) == index] = 0

        # 应用掩码到损失上
        loss = loss * mask
        return loss.sum() / torch.ones_like(loss, device=loss.device).sum()

    def backward_G(self):
        """Calculate GAN and L1 loss for the generator"""
        # mask = self.create_ignore_mask(self.gt_mask, ignore_index=self.ignore_index)

        loss = self.criterionBCE(
            self.pred_mask, torch.argmax(self.gt_mask, dim=1, keepdim=True).squeeze(1)
        )  # (1,4,1024,1024)
        # print(
        #     f'未忽略类别loss:{self.criterionBCE(self.pred_mask, self.gt_mask).mean()}'
        # )
        # guanfang_crt = torch.nn.CrossEntropyLoss(ignore_index=0)
        # guanfang_loss = guanfang_crt(
        #     self.pred_mask, torch.argmax(self.gt_mask, dim=1, keepdim=True).squeeze(1)
        # )
        # print(f'guanfang忽略类别loss:{guanfang_loss}')
        # loss = self.get_ignore_mask_loss(loss, ignore_index=self.ignore_index)
        # print(f'忽略类别loss:{loss}')

        # loss = loss * mask  # 应用掩码
        # loss = loss.sum() / mask.sum()  # 仅计算非忽略像素的损失
        self.loss_G = loss
        # if self.loss_mode == 'iou':
        # self.loss_G += _iou_loss(self.pred_mask, self.gt_mask)

        self.loss_G.backward()

    def optimize_parameters(self):
        self.forward()
        self.optimizer.zero_grad()  # set G's gradients to zero
        self.backward_G()  # calculate graidents for G
        self.optimizer.step()  # udpate G's weights

    def set_requires_grad(self, nets, requires_grad=False):
        """Set requies_grad=Fasle for all the networks to avoid unnecessary computations
        Parameters:
            nets (network list)   -- a list of networks
            requires_grad (bool)  -- whether the networks require gradients or not
        """
        if not isinstance(nets, list):
            nets = [nets]
        for net in nets:
            if net is not None:
                for param in net.parameters():
                    param.requires_grad = requires_grad